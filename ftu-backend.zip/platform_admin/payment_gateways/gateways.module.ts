// File: ftu-backend/src/platform_admin/payment_gateways/gateways.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GatewaysService } from './gateways.service';
import { GatewaysController } from './gateways.controller';
import { Gateway } from './entities/gateway.entity';
import { AuthModule } from '../../core/auth/auth.module'; // Sẽ cần cho Guard sau này

@Module({
  imports: [
    TypeOrmModule.forFeature([Gateway]),
    AuthModule, // Import để chuẩn bị cho việc sử dụng Guards
  ],
  controllers: [GatewaysController],
  providers: [GatewaysService],
  exports: [GatewaysService], // Xuất service để các module khác có thể dùng
})
export class GatewaysModule {}