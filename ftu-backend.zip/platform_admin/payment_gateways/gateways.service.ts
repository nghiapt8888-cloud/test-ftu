// File: ftu-backend/src/platform_admin/payment_gateways/gateways.service.ts
import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Gateway } from './entities/gateway.entity';
import { CreateGatewayDto } from './dto/create-gateway.dto';
import { UpdateGatewayDto } from './dto/update-gateway.dto';
import { EncryptionService } from '../../shared/services/encryption.service'; // <-- IMPORT MỚI

@Injectable()
export class GatewaysService {
    constructor(
        @InjectRepository(Gateway)
        private readonly gatewayRepository: Repository<Gateway>,
        private readonly encryptionService: EncryptionService, // <-- INJECT MỚI
    ) {}

    /**
     * Tạo một cổng thanh toán mới.
     */
    async create(createGatewayDto: CreateGatewayDto): Promise<Gateway> {
        const existing = await this.gatewayRepository.findOne({
            where: { gatewayCode: createGatewayDto.gatewayCode },
        });

        if (existing) {
            throw new ConflictException(`Mã cổng thanh toán '${createGatewayDto.gatewayCode}' đã tồn tại.`);
        }
        
        // Mã hóa cấu hình trước khi tạo
        const encryptedConfig = this.encryptionService.encrypt(JSON.stringify(createGatewayDto.config));

        const gateway = this.gatewayRepository.create({
            ...createGatewayDto,
            config: encryptedConfig, // <-- SỬ DỤNG CONFIG ĐÃ MÃ HÓA
        });
        return this.gatewayRepository.save(gateway);
    }

    /**
     * Lấy tất cả các cổng thanh toán (dành cho trang quản trị).
     */
    async findAll(): Promise<Gateway[]> {
        return this.gatewayRepository.find({ order: { createdAt: 'DESC' } });
    }

    /**
     * Lấy tất cả các cổng thanh toán đang hoạt động (dành cho người dùng cuối).
     * Lưu ý: Hàm này không giải mã config vì không cần thiết ở phía client.
     */
    async findAllActive(): Promise<Gateway[]> {
        return this.gatewayRepository.find({
            where: { isActive: true },
            order: { gatewayName: 'ASC' },
            select: ['id', 'gatewayName', 'gatewayCode', 'logoUrl', 'description'] // Chỉ lấy các trường công khai
        });
    }

    /**
     * Tìm một cổng thanh toán theo ID.
     */
    async findOne(id: string): Promise<Gateway> {
        const gateway = await this.gatewayRepository.findOne({ where: { id } });
        if (!gateway) {
            throw new NotFoundException(`Không tìm thấy cổng thanh toán với ID '${id}'.`);
        }
        // Khi admin xem chi tiết, ta sẽ giải mã config để hiển thị
        gateway.config = JSON.parse(this.encryptionService.decrypt(gateway.config));
        return gateway;
    }

    /**
     * Cập nhật thông tin một cổng thanh toán.
     */
    async update(id: string, updateGatewayDto: UpdateGatewayDto): Promise<Gateway> {
        const gateway = await this.gatewayRepository.findOne({ where: { id } });
        if (!gateway) {
            throw new NotFoundException(`Không tìm thấy cổng thanh toán với ID '${id}'.`);
        }

        // Kiểm tra nếu gatewayCode mới đã tồn tại ở một gateway khác
        if (updateGatewayDto.gatewayCode && updateGatewayDto.gatewayCode !== gateway.gatewayCode) {
             const existing = await this.gatewayRepository.findOne({
                where: { gatewayCode: updateGatewayDto.gatewayCode },
            });
            if (existing) {
                throw new ConflictException(`Mã cổng thanh toán '${updateGatewayDto.gatewayCode}' đã tồn tại.`);
            }
        }
        
        // Nếu có cập nhật config, mã hóa nó
        if (updateGatewayDto.config) {
            updateGatewayDto.config = this.encryptionService.encrypt(JSON.stringify(updateGatewayDto.config));
        }

        // Trộn DTO vào entity đã tìm thấy và lưu lại
        Object.assign(gateway, updateGatewayDto);
        const updatedGateway = await this.gatewayRepository.save(gateway);

        // Giải mã config trước khi trả về cho client
        updatedGateway.config = JSON.parse(this.encryptionService.decrypt(updatedGateway.config));
        return updatedGateway;
    }

    /**
     * Xóa một cổng thanh toán.
     */
    async remove(id: string): Promise<void> {
        const result = await this.gatewayRepository.delete(id);
        if (result.affected === 0) {
            throw new NotFoundException(`Không tìm thấy cổng thanh toán với ID '${id}'.`);
        }
    }
}