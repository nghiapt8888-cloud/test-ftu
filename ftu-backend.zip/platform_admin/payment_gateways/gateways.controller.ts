// File: ftu-backend/src/platform_admin/payment_gateways/gateways.controller.ts
import { Controller, Get, Post, Body, Patch, Param, Delete, ParseUUIDPipe, UseGuards } from '@nestjs/common';
import { GatewaysService } from './gateways.service';
import { CreateGatewayDto } from './dto/create-gateway.dto';
import { UpdateGatewayDto } from './dto/update-gateway.dto';
import { JwtAuthGuard } from '../../core/auth/guards/jwt-auth.guard';
import { SystemAdminGuard } from '../../core/auth/guards/system-admin.guard';

// Đổi route chính để API gọn gàng hơn
@Controller('payment-gateways')
export class GatewaysController {
  constructor(private readonly gatewaysService: GatewaysService) {}

  // --- ADMIN ENDPOINTS (Bảo vệ bởi Guard) ---

  @Post()
  @UseGuards(JwtAuthGuard, SystemAdminGuard)
  create(@Body() createGatewayDto: CreateGatewayDto) {
    return this.gatewaysService.create(createGatewayDto);
  }

  @Get()
  @UseGuards(JwtAuthGuard, SystemAdminGuard)
  findAll() {
    return this.gatewaysService.findAll();
  }

  @Get(':id')
  @UseGuards(JwtAuthGuard, SystemAdminGuard)
  findOne(@Param('id', new ParseUUIDPipe()) id: string) {
    return this.gatewaysService.findOne(id);
  }

  @Patch(':id')
  @UseGuards(JwtAuthGuard, SystemAdminGuard)
  update(@Param('id', new ParseUUIDPipe()) id: string, @Body() updateGatewayDto: UpdateGatewayDto) {
    return this.gatewaysService.update(id, updateGatewayDto);
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard, SystemAdminGuard)
  remove(@Param('id', new ParseUUIDPipe()) id: string) {
    return this.gatewaysService.remove(id);
  }

  // --- PUBLIC ENDPOINT (Công khai cho người dùng) ---

  @Get('active')
  findAllActive() {
    return this.gatewaysService.findAllActive();
  }
}