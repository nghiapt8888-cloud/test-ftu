// File: ftu-backend/src/platform_admin/payment_gateways/entities/gateway.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, Index } from 'typeorm';

@Entity('payment_gateways')
export class Gateway {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Column({ name: 'gateway_name' })
    gatewayName: string; // Ví dụ: "Ví điện tử MoMo", "Cổng thanh toán VNPAY"

    @Index({ unique: true })
    @Column({ name: 'gateway_code', unique: true })
    gatewayCode: string; // Mã duy nhất, ví dụ: "MOMO_EWALLET", "VNPAY_QR"

    @Column({ type: 'text', nullable: true })
    description: string; // Mô tả ngắn

    @Column({ name: 'logo_url', type: 'text', nullable: true })
    logoUrl: string; // Đường dẫn đến logo của cổng thanh toán

    /**
     * Lưu trữ cấu hình nhạy cảm dưới dạng JSON.
     * Ví dụ: {
     * "partnerCode": "...",
     * "accessKey": "...",
     * "secretKey": "...",
     * "apiEndpoint": "https://test-payment.momo.vn/v2/gateway/api/create"
     * }
     * Cần được mã hóa trước khi lưu vào DB trong môi trường production.
     */
    @Column({ type: 'jsonb' })
    config: any;

    @Column({ default: true })
    isActive: boolean; // Cho phép bật/tắt nhanh cổng thanh toán này

    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;

    @UpdateDateColumn({ name: 'updated_at' })
    updatedAt: Date;
}