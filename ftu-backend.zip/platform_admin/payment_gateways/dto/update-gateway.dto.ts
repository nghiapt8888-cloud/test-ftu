// File: ftu-backend/src/platform_admin/payment_gateways/dto/update-gateway.dto.ts
import { IsString, IsOptional, IsObject, IsBoolean, IsUrl } from 'class-validator';

export class UpdateGatewayDto {
    @IsOptional()
    @IsString()
    gatewayName?: string;

    @IsOptional()
    @IsString()
    // @Matches(/^[A-Z_]+$/, { message: 'Mã cổng thanh toán chỉ được chứa chữ hoa và dấu gạch dưới.' })
    gatewayCode?: string;

    @IsOptional()
    @IsString()
    description?: string;

    @IsOptional()
    @IsUrl({}, { message: 'Logo URL không hợp lệ.'})
    logoUrl?: string;

    @IsOptional()
    @IsObject({ message: 'Cấu hình phải là một đối tượng JSON.' })
    config?: any;

    @IsOptional()
    @IsBoolean()
    isActive?: boolean;
}