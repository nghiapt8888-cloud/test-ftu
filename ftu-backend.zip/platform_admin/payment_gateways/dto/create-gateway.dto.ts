// File: ftu-backend/src/platform_admin/payment_gateways/dto/create-gateway.dto.ts
import { IsString, IsNotEmpty, IsOptional, IsObject, IsBoolean, IsUrl } from 'class-validator';

export class CreateGatewayDto {
    @IsNotEmpty({ message: 'Tên cổng thanh toán không được để trống.' })
    @IsString()
    gatewayName: string;

    @IsNotEmpty({ message: 'Mã cổng thanh toán không được để trống.' })
    @IsString()
    // Thêm validation pattern nếu cần, ví dụ: chỉ chấp nhận chữ hoa và dấu gạch dưới
    // @Matches(/^[A-Z_]+$/, { message: 'Mã cổng thanh toán chỉ được chứa chữ hoa và dấu gạch dưới.' })
    gatewayCode: string;

    @IsOptional()
    @IsString()
    description: string;

    @IsOptional()
    @IsUrl({}, { message: 'Logo URL không hợp lệ.'})
    logoUrl: string;

    @IsNotEmpty({ message: 'Cấu hình không được để trống.' })
    @IsObject({ message: 'Cấu hình phải là một đối tượng JSON.' })
    config: any;

    @IsOptional()
    @IsBoolean()
    isActive: boolean;
}