// File: ftu-backend/src/platform_admin/communications_config/entities/comm-provider.entity.ts
import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('comm_providers')
export class CommProvider {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Column()
    providerName: string; // Ví dụ: "SMTP Gmail", "SendGrid API"

    @Column({ unique: true })
    providerCode: string; // Ví dụ: "SMTP_GMAIL", "SENDGRID_API"

    @Column({ type: 'jsonb' })
    config: any; // Lưu trữ API Key, Secret, Host, Port...

    @Column({ default: false })
    isActive: boolean;
}