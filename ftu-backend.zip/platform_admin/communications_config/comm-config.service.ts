// File: ftu-backend/src/platform_admin/communications_config/comm-config.service.ts
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CommProvider } from './entities/comm-provider.entity';
import { CreateCommProviderDto } from './dto/create-comm-provider.dto';
import { UpdateCommProviderDto } from './dto/update-comm-provider.dto';
import { EncryptionService } from '../../shared/services/encryption.service'; // <-- IMPORT MỚI

@Injectable()
export class CommConfigService {
    constructor(
        @InjectRepository(CommProvider)
        private readonly commProviderRepository: Repository<CommProvider>,
        private readonly encryptionService: EncryptionService, // <-- INJECT MỚI
    ) {}

    async create(createDto: CreateCommProviderDto): Promise<CommProvider> {
        // Mã hóa cấu hình trước khi lưu
        const encryptedConfig = this.encryptionService.encrypt(JSON.stringify(createDto.config));
        
        const newProvider = this.commProviderRepository.create({
            ...createDto,
            config: encryptedConfig, // <-- SỬ DỤNG CONFIG ĐÃ MÃ HÓA
        });

        return this.commProviderRepository.save(newProvider);
    }

    async findAll(): Promise<CommProvider[]> {
        // Không trả về config trong danh sách chung
        return this.commProviderRepository.find({
            select: ['id', 'providerName', 'providerCode', 'isActive']
        });
    }
    
    async findOne(id: string): Promise<CommProvider> {
        const provider = await this.commProviderRepository.findOne({ where: { id } });
        if (!provider) {
            throw new NotFoundException(`Nhà cung cấp với ID ${id} không tồn tại.`);
        }
        // Giải mã config để admin có thể xem và sửa
        provider.config = JSON.parse(this.encryptionService.decrypt(provider.config));
        return provider;
    }

    async findActive(): Promise<CommProvider[]> {
        return this.commProviderRepository.find({ 
            where: { isActive: true },
            select: ['id', 'providerName', 'providerCode', 'isActive'] // Chỉ lấy các trường công khai
        });
    }

    async update(id: string, updateDto: UpdateCommProviderDto): Promise<CommProvider> {
        const provider = await this.commProviderRepository.findOne({ where: { id } });
        if (!provider) {
            throw new NotFoundException(`Nhà cung cấp với ID ${id} không tồn tại.`);
        }

        // Nếu có cập nhật config, mã hóa nó
        if (updateDto.config) {
            updateDto.config = this.encryptionService.encrypt(JSON.stringify(updateDto.config));
        }

        this.commProviderRepository.merge(provider, updateDto);
        const updatedProvider = await this.commProviderRepository.save(provider);
        
        // Giải mã config trước khi trả về cho client
        updatedProvider.config = JSON.parse(this.encryptionService.decrypt(updatedProvider.config));
        return updatedProvider;
    }

    async remove(id: string): Promise<void> {
        const result = await this.commProviderRepository.delete(id);
        if (result.affected === 0) {
            throw new NotFoundException(`Nhà cung cấp với ID ${id} không tồn tại.`);
        }
    }
}