// File: ftu-backend/src/platform_admin/communications_config/comm-config.controller.ts
import { Controller, Get, Post, Body, Patch, Param, Delete, ParseUUIDPipe, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../../../core/auth/guards/jwt-auth.guard';
import { SystemAdminGuard } from '../../../core/auth/guards/system-admin.guard';
import { CommConfigService } from './comm-config.service';
import { CreateCommProviderDto } from './dto/create-comm-provider.dto';
import { UpdateCommProviderDto } from './dto/update-comm-provider.dto';

@UseGuards(JwtAuthGuard, SystemAdminGuard)
@Controller('platform_admin/communications-config')
export class CommConfigController {
    constructor(private readonly commConfigService: CommConfigService) {}

    @Post()
    create(@Body() createDto: CreateCommProviderDto) {
        return this.commConfigService.create(createDto);
    }

    @Get()
    findAll() {
        return this.commConfigService.findAll();
    }

    @Get('active')
    findActive() {
        return this.commConfigService.findActive();
    }

    @Patch(':id')
    update(
        @Param('id', ParseUUIDPipe) id: string,
        @Body() updateDto: UpdateCommProviderDto,
    ) {
        return this.commConfigService.update(id, updateDto);
    }

    @Delete(':id')
    remove(@Param('id', ParseUUIDPipe) id: string) {
        return this.commConfigService.remove(id);
    }
}