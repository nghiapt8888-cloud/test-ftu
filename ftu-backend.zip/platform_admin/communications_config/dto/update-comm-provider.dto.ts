// File: ftu-backend/src/platform_admin/communications_config/dto/update-comm-provider.dto.ts
import { IsString, IsOptional, IsObject, IsBoolean } from 'class-validator';

export class UpdateCommProviderDto {
    @IsOptional()
    @IsString()
    providerName?: string;

    @IsOptional()
    @IsString()
    providerCode?: string;

    @IsOptional()
    @IsString()
    description?: string;

    @IsOptional()
    @IsObject({ message: 'Cấu hình phải là một đối tượng JSON.' })
    config?: any;

    @IsOptional()
    @IsBoolean()
    isActive?: boolean;
}