// File: ftu-backend/src/platform_admin/communications_config/dto/create-comm-provider.dto.ts
import { IsString, IsNotEmpty, IsOptional, IsObject, IsBoolean, IsUrl } from 'class-validator';

export class CreateCommProviderDto {
    @IsNotEmpty({ message: 'Tên nhà cung cấp không được để trống.' })
    @IsString()
    providerName: string;

    @IsNotEmpty({ message: 'Mã nhà cung cấp không được để trống.' })
    @IsString()
    providerCode: string;

    @IsOptional()
    @IsString()
    description?: string;

    @IsNotEmpty({ message: 'Cấu hình không được để trống.' })
    @IsObject({ message: 'Cấu hình phải là một đối tượng JSON.' })
    config: any;

    @IsOptional()
    @IsBoolean()
    isActive: boolean;
}