// File: ftu-backend/src/platform_admin/webhooks_monitor/entities/webhook-log.entity.ts
import { Subscription } from '../../../modules/billing/entities/subscription.entity';
import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
} from 'typeorm';

export type WebhookStatus = 'success' | 'failed' | 'retrying';

@Entity('webhook_logs')
export class WebhookLog {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  // Webhook này được kích hoạt bởi subscription nào?
  @ManyToOne(() => Subscription)
  @JoinColumn({ name: 'subscription_id' })
  subscription: Subscription;

  @Column({ name: 'event_type' })
  eventType: string; // ví dụ: 'subscription.created', 'subscription.renewed'

  @Column({ name: 'endpoint_url', type: 'text' })
  endpointUrl: string; // URL của đối tác đã nhận webhook

  @Column({ type: 'jsonb' })
  payload: any; // Nội dung đã gửi đi

  @Column({
    type: 'enum',
    enum: ['success', 'failed', 'retrying'],
  })
  status: WebhookStatus;

  @Column({ name: 'response_status_code', nullable: true })
  responseStatusCode: number; // Mã HTTP status từ server của đối tác (200, 404, 500...)

  @Column({ name: 'response_body', type: 'text', nullable: true })
  responseBody: string; // Nội dung phản hồi từ server của đối tác (nếu có)

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;
}