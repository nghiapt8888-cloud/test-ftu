// File: ftu-backend/src/platform_admin/partner_management/partner-management.controller.ts
import { Controller, Get, Patch, Param, Body, UseGuards, ParseUUIDPipe } from '@nestjs/common';
import { JwtAuthGuard } from '../../core/auth/guards/jwt-auth.guard';
import { SystemAdminGuard } from '../../core/auth/guards/system-admin.guard';
import { PartnersService } from '../../modules/partners/partners.service';
import { UpdatePartnerStatusDto } from './dto/update-partner-status.dto';

@Controller('platform_admin/partners')
@UseGuards(JwtAuthGuard, SystemAdminGuard)
export class PartnerManagementController {
    constructor(private readonly partnersService: PartnersService) {}

    @Get()
    findAll() {
        return this.partnersService.findAllPartners();
    }

    @Get(':id')
    findOne(@Param('id', ParseUUIDPipe) id: string) {
        return this.partnersService.findPartnerById(id);
    }

    @Patch(':id/status')
    updateStatus(
        @Param('id', ParseUUIDPipe) id: string,
        @Body() updatePartnerStatusDto: UpdatePartnerStatusDto,
    ) {
        return this.partnersService.updatePartnerStatus(id, updatePartnerStatusDto.status);
    }
}