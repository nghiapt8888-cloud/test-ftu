// File: ftu-backend/src/platform_admin/partner_management/dto/update-partner-status.dto.ts
import { IsEnum, IsNotEmpty } from 'class-validator';
import { PartnerStatus } from '../../../modules/partners/entities/partner.entity';

export class UpdatePartnerStatusDto {
    @IsNotEmpty({ message: 'Trạng thái không được để trống.' })
    @IsEnum(['pending_approval', 'approved', 'rejected', 'suspended'], {
        message: 'Trạng thái không hợp lệ.',
    })
    status: PartnerStatus;
}