// File: ftu-backend/src/platform_admin/partner_management/partner-management.module.ts
import { Module } from '@nestjs/common';
import { PartnerManagementController } from './partner-management.controller';
import { PartnersModule } from '../../modules/partners/partners.module'; // Import để sử dụng PartnersService
import { AuthModule } from '../../core/auth/auth.module';

@Module({
  imports: [
    PartnersModule, // Cần PartnersService
    AuthModule,     // Cần các Guard
  ],
  controllers: [PartnerManagementController],
})
export class PartnerManagementModule {}