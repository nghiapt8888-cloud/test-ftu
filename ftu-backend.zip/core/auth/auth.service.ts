// File: ftu-backend/src/core/auth/auth.service.ts
import { Injectable, ConflictException, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { DataSource } from 'typeorm';
import * as bcrypt from 'bcrypt';

import { AccountsService } from '../../modules/accounts/accounts.service';
import { OrganizationsService } from '../../modules/organizations/organizations.service';
import { RegisterDto } from './dto/register.dto';
import { User } from '../../modules/accounts/entities/user.entity';

@Injectable()
export class AuthService {
    constructor(
        private readonly dataSource: DataSource, // Để thực hiện transaction
        private readonly accountsService: AccountsService,
        private readonly organizationsService: OrganizationsService,
        private readonly jwtService: JwtService,
    ) {}

    /**
     * Xác thực người dùng bằng email và mật khẩu.
     */
    async validateUser(email: string, pass: string): Promise<Omit<User, 'password'>> {
        const user = await this.accountsService.findByEmail(email);
        if (user && await bcrypt.compare(pass, user.password)) {
            const { password, ...result } = user;
            return result;
        }
        throw new UnauthorizedException('Thông tin đăng nhập không chính xác.');
    }

    /**
     * Xử lý luồng đăng ký người dùng và tạo tổ chức mới.
     * Sử dụng transaction để đảm bảo tất cả các bước đều thành công hoặc thất bại cùng nhau.
     */
    async register(registerDto: RegisterDto) {
        const { email, password, companyName, firstName, lastName } = registerDto;

        const existingUser = await this.accountsService.findByEmail(email);
        if (existingUser) {
            throw new ConflictException('Email này đã được sử dụng.');
        }

        // Bắt đầu một transaction
        return this.dataSource.transaction(async (manager) => {
            // 1. Tạo User mới
            const userEntity = manager.create(User, { email, password, firstName, lastName });
            const hashedPassword = await bcrypt.hash(password, 10);
            userEntity.password = hashedPassword;
            const newUser = await manager.save(userEntity);

            // 2. Tạo Organization mới với User vừa tạo làm owner
            const orgEntity = await this.organizationsService.create(companyName, newUser);
            const newOrg = await manager.save(orgEntity);

            // 3. Tạo Membership để gán vai trò 'owner' cho User trong Organization đó
            await this.organizationsService.createMembership(newUser.id, newOrg.id, 'owner');
            
            // Nếu mọi thứ thành công, trả về token đăng nhập
            // Phải lấy lại thông tin user đầy đủ để có systemRole
            const userWithRole = await this.accountsService.findById(newUser.id);
            const { password, ...result } = userWithRole;
            return this.login(result);
        });
    }

    /**
     * Tạo và trả về JWT token sau khi đăng nhập thành công.
     */
    async login(user: Omit<User, 'password'>) {
        const payload = { 
            email: user.email, 
            sub: user.id, 
            systemRole: user.systemRole
        };
        return {
            access_token: this.jwtService.sign(payload),
        };
    }
}