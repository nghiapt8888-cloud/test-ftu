// File: ftu-backend/src/core/auth/dto/register.dto.ts
import { IsEmail, IsString, MinLength, IsNotEmpty } from 'class-validator';

export class RegisterDto {
    @IsNotEmpty({ message: 'Tên công ty không được để trống.' })
    @IsString()
    companyName: string;

    @IsNotEmpty({ message: 'Email không được để trống.' })
    @IsEmail({}, { message: 'Email không hợp lệ.' })
    email: string;

    @IsNotEmpty({ message: 'Mật khẩu không được để trống.' })
    @MinLength(6, { message: 'Mật khẩu phải có ít nhất 6 ký tự.' })
    password: string;

    // Các trường thông tin cá nhân khác có thể thêm vào đây, ví dụ:
    @IsNotEmpty({ message: 'Tên không được để trống.' })
    @IsString()
    firstName: string;

    @IsNotEmpty({ message: 'Họ không được để trống.' })
    @IsString()
    lastName: string;
}