// File: ftu-backend/src/core/auth/dto/login.dto.ts
import { IsEmail, IsString, IsNotEmpty } from 'class-validator';

export class LoginDto {
    @IsNotEmpty({ message: 'Email không được để trống.' })
    @IsEmail()
    email: string;

    @IsNotEmpty({ message: 'Mật khẩu không được để trống.' })
    @IsString()
    password: string;
}