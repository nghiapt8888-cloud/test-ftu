// File: ftu-backend/src/core/auth/guards/system-admin.guard.ts
import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Observable } from 'rxjs';
import { User } from '../../../modules/accounts/entities/user.entity';

@Injectable()
export class SystemAdminGuard implements CanActivate {
  canActivate(
    context: ExecutionContext,
  ): boolean | Promise<boolean> | Observable<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user as User;

    // JwtAuthGuard đã chạy trước và gắn `user` vào request.
    // Nếu không có user hoặc user không có vai trò SYSTEM_ADMIN, từ chối truy cập.
    if (!user || user.systemRole !== 'SYSTEM_ADMIN') {
      throw new ForbiddenException('Bạn không có quyền truy cập vào tài nguyên này.');
    }

    return true;
  }
}