// File: ftu-backend/src/core/auth/guards/organization-member.guard.ts
import { Injectable, CanActivate, ExecutionContext, ForbiddenException, BadRequestException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Request } from 'express';
import { User } from '../../../modules/accounts/entities/user.entity';
import { OrganizationsService } from '../../../modules/organizations/organizations.service';
import { MembershipRole } from '../../../modules/organizations/entities/membership.entity';
import { ROLES_KEY } from '../decorators/roles.decorator';

@Injectable()
export class OrganizationMemberGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly organizationsService: OrganizationsService
  ) {}

  async canActivate(
    context: ExecutionContext,
  ): Promise<boolean> {
    const requiredRoles = this.reflector.getAllAndOverride<MembershipRole[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    const request: Request = context.switchToHttp().getRequest();
    const user = request.user as User;

    // Lấy organizationId từ request params hoặc body.
    const organizationId = request.params.orgId || request.body.organizationId;
    
    if (!user) {
      throw new ForbiddenException('Yêu cầu xác thực không hợp lệ.');
    }

    if (!organizationId) {
      throw new BadRequestException('Bắt buộc phải cung cấp ID của tổ chức (organizationId).');
    }

    // Tìm kiếm thông tin thành viên của user trong tổ chức này
    const membership = await this.organizationsService.findMembership(organizationId, user.id);

    if (!membership) {
      throw new ForbiddenException('Bạn không phải là thành viên của tổ chức này.');
    }
    
    // Gắn thông tin membership vào request để có thể dùng ở các bước sau nếu cần
    (request as any).membership = membership;

    // Nếu endpoint không yêu cầu vai trò cụ thể, chỉ cần là thành viên là đủ
    if (!requiredRoles || requiredRoles.length === 0) {
      return true;
    }

    // Kiểm tra xem vai trò của thành viên có nằm trong danh sách vai trò yêu cầu không
    const hasRequiredRole = requiredRoles.some((role) => membership.role === role);

    if (!hasRequiredRole) {
        throw new ForbiddenException('Bạn không có quyền thực hiện hành động này.');
    }

    return true;
  }
}