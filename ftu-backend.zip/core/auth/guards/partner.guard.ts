// File: ftu-backend/src/core/auth/guards/partner.guard.ts
import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Observable } from 'rxjs';
import { User } from '../../../modules/accounts/entities/user.entity';

@Injectable()
export class PartnerGuard implements CanActivate {
  canActivate(
    context: ExecutionContext,
  ): boolean | Promise<boolean> | Observable<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user as User;
    
    // Kiểm tra xem người dùng có tồn tại và vai trò là PARTNER hay không.
    // Dữ liệu `user` đã được gắn vào request từ JwtAuthGuard.
    // Cho phép cả SYSTEM_ADMIN để họ có thể quản lý đối tác.
    if (!user || (user.systemRole !== 'PARTNER' && user.systemRole !== 'SYSTEM_ADMIN')) {
      throw new ForbiddenException('Bạn không có quyền truy cập vào khu vực đối tác.');
    }

    return true;
  }
}