// File: ftu-backend/src/core/auth/decorators/roles.decorator.ts
import { SetMetadata } from '@nestjs/common';
import { MembershipRole } from '../../modules/organizations/entities/membership.entity';

export const ROLES_KEY = 'roles';
export const Roles = (...roles: MembershipRole[]) => SetMetadata(ROLES_KEY, roles);