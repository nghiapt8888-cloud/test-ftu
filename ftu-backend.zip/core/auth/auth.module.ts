// File: ftu-backend/src/core/auth/auth.module.ts
import { Module, forwardRef } from '@nestjs/common';
import { PassportModule } from '@nestjs/passport';
import { JwtModule } from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';

import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { AccountsModule } from '../../modules/accounts/accounts.module';
import { OrganizationsModule } from '../../modules/organizations/organizations.module';
import { JwtStrategy } from './strategies/jwt.strategy';
import { SystemAdminGuard } from './guards/system-admin.guard';
import { OrganizationMemberGuard } from './guards/organization-member.guard';
import { PartnerGuard } from './guards/partner.guard'; 

@Module({
  imports: [
    // forwardRef(() => AccountsModule), // Sử dụng forwardRef nếu có lỗi circular dependency
    // forwardRef(() => OrganizationsModule),
    AccountsModule,
    OrganizationsModule,
    PassportModule,
    JwtModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: async (configService: ConfigService) => ({
        secret: configService.get<string>('JWT_SECRET', 'YOUR_DEFAULT_SECRET_KEY_32_CHARS'),
        signOptions: { expiresIn: '1d' },
      }),
    }),
  ],
  providers: [
    AuthService, 
    JwtStrategy, 
    SystemAdminGuard,
    OrganizationMemberGuard,
    PartnerGuard,
  ],
  controllers: [AuthController],
  exports: [SystemAdminGuard, OrganizationMemberGuard, PartnerGuard]
})
export class AuthModule {}