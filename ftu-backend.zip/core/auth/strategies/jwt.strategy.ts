// File: ftu-backend/src/core/auth/strategies/jwt.strategy.ts
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { Strategy, ExtractJwt } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';
import { AccountsService } from '../../../modules/accounts/accounts.service';
import { User } from '../../../modules/accounts/entities/user.entity';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
    constructor(
        private readonly configService: ConfigService,
        private readonly accountsService: AccountsService,
    ) {
        super({
            jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
            ignoreExpiration: false,
            secretOrKey: configService.get<string>('JWT_SECRET', 'YOUR_DEFAULT_SECRET_KEY_32_CHARS'),
        });
    }

    /**
     * Hàm này được Passport tự động gọi sau khi xác thực token thành công.
     * Payload là đối tượng chúng ta đã mã hóa vào token trong hàm authService.login().
     */
    async validate(payload: { sub: number; email: string }): Promise<Omit<User, 'password'>> {
        const user = await this.accountsService.findById(payload.sub);

        if (!user) {
            throw new UnauthorizedException('User not found.');
        }

        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { password, ...result } = user;
        // Đối tượng trả về sẽ được gắn vào req.user của request
        return result;
    }
}