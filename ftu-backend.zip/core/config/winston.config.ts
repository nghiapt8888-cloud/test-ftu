// File: ftu-backend/src/core/config/winston.config.ts
import { transports, format } from 'winston';
import * as DailyRotateFile from 'winston-daily-rotate-file';

export const winstonConfig = {
  transports: [
    // Transport để hiển thị log trên console
    new transports.Console({
      format: format.combine(
        format.timestamp(),
        format.ms(),
        format.colorize({ all: true }), // Thêm màu sắc cho dễ đọc
        format.printf((info) => {
          const { timestamp, level, message, context, ...meta } = info;
          return `${timestamp} [${context || 'Application'}] ${level}: ${message} ${
            Object.keys(meta).length ? JSON.stringify(meta, null, 2) : ''
          }`;
        }),
      ),
    }),
    
    // Transport để ghi tất cả log vào file, tự động xoay file theo ngày
    new DailyRotateFile({
      filename: 'logs/application-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      zippedArchive: true,
      maxSize: '20m',
      maxFiles: '14d', // Giữ log trong 14 ngày
      format: format.combine(
        format.timestamp(),
        format.json(), // Ghi log dưới dạng JSON
      ),
    }),

    // Transport để chỉ ghi riêng các log lỗi vào file
    new DailyRotateFile({
      level: 'error',
      filename: 'logs/error-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      zippedArchive: true,
      maxSize: '20m',
      maxFiles: '30d', // Giữ log lỗi lâu hơn, trong 30 ngày
      format: format.combine(
        format.timestamp(),
        format.json(),
      ),
    }),
  ],
};