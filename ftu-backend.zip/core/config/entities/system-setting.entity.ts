// File: ftu-backend/src/core/config/entities/system-setting.entity.ts
import { Entity, PrimaryColumn, Column } from 'typeorm';

@Entity('system_settings')
export class SystemSetting {
    @PrimaryColumn()
    key: string; // ví dụ: 'registration_fields', 'wallet_config', 'p2p_transfer_rules'

    @Column({ type: 'jsonb' })
    value: any; // ví dụ: { required: ['firstName', 'lastName'], optional: ['phone'] }
}