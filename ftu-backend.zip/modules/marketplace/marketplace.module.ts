// File: ftu-backend/src/modules/marketplace/marketplace.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MarketplaceService } from './marketplace.service';
import { MarketplaceController } from './marketplace.controller';
import { Solution } from './entities/solution.entity';
import { Plan } from './entities/plan.entity';
import { Category } from './entities/category.entity';
import { AuthModule } from '../../core/auth/auth.module'; // Import AuthModule để sử dụng Guards

@Module({
  imports: [
    TypeOrmModule.forFeature([Solution, Plan, Category]),
    AuthModule, // Cần thiết để bảo vệ các endpoints
  ],
  controllers: [MarketplaceController],
  providers: [MarketplaceService],
  exports: [MarketplaceService], // Xuất service để module Billing có thể sử dụng
})
export class MarketplaceModule {}