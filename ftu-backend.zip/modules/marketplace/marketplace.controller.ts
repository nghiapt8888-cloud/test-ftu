// File: ftu-backend/src/modules/marketplace/marketplace.controller.ts
import { Controller, Get, Post, Body, Param, UseGuards, Req, ParseUUIDPipe } from '@nestjs/common';
import { MarketplaceService } from './marketplace.service';
import { JwtAuthGuard } from '../../core/auth/guards/jwt-auth.guard';
import { User } from '../accounts/entities/user.entity';
import { PartnerGuard } from '../../core/auth/guards/partner.guard'; // <-- IMPORT MỚI

@Controller('marketplace')
export class MarketplaceController {
    constructor(private readonly marketplaceService: MarketplaceService) {}

    // --- Public Endpoints (Ai cũng có thể xem) ---

    @Get('categories')
    findAllCategories() {
        return this.marketplaceService.findAllCategories();
    }

    @Get('solutions')
    findAllSolutions() {
        return this.marketplaceService.findAllSolutions();
    }

    @Get('solutions/:id')
    findSolutionById(@Param('id', ParseUUIDPipe) id: string) {
        return this.marketplaceService.findSolutionById(id);
    }

    @Get('solutions/:id/plans')
    findPlansBySolution(@Param('id', ParseUUIDPipe) id: string) {
        return this.marketplaceService.findPlansBySolution(id);
    }

    // --- Admin & Partner Endpoints ---
    // Các endpoint này yêu cầu người dùng đăng nhập
    // và có vai trò là Partner hoặc Admin hệ thống

    @UseGuards(JwtAuthGuard)
    @Post('categories')
    createCategory(@Body() dto: any, @Req() req: { user: User }) {
        // Service sẽ kiểm tra quyền SYSTEM_ADMIN
        return this.marketplaceService.createCategory(dto, req.user);
    }
    
    @UseGuards(JwtAuthGuard, PartnerGuard) // <-- BẢO VỆ ENDPOINT
    @Post('solutions')
    createSolution(@Body() dto: any, @Req() req: { user: User }) {
        // Service sẽ kiểm tra quyền Partner
        return this.marketplaceService.createSolution(dto, req.user);
    }

    @UseGuards(JwtAuthGuard, PartnerGuard) // <-- BẢO VỆ ENDPOINT
    @Post('solutions/:id/plans')
    createPlan(
        @Param('id', ParseUUIDPipe) solutionId: string,
        @Body() dto: any,
        @Req() req: { user: User }
    ) {
        // Service sẽ kiểm tra quyền Partner và quyền sở hữu
        return this.marketplaceService.createPlan(solutionId, dto, req.user);
    }
}