// File: ftu-backend/src/modules/marketplace/marketplace.service.ts
import { Injectable, NotFoundException, UnauthorizedException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Category } from './entities/category.entity';
import { Solution } from './entities/solution.entity';
import { Plan } from './entities/plan.entity';
import { User } from '../accounts/entities/user.entity';
import { Partner } from '../partners/entities/partner.entity';

@Injectable()
export class MarketplaceService {
    constructor(
        @InjectRepository(Category) private readonly categoryRepository: Repository<Category>,
        @InjectRepository(Solution) private readonly solutionRepository: Repository<Solution>,
        @InjectRepository(Plan) private readonly planRepository: Repository<Plan>,
        @InjectRepository(Partner) private readonly partnerRepository: Repository<Partner>,
    ) {}

    // --- Helper function to check ownership ---
    private async getPartnerFromUser(user: User): Promise<Partner> {
        if (user.systemRole !== 'PARTNER') return null;
        const partner = await this.partnerRepository.findOne({ where: { user: { id: user.id } } });
        if (!partner || partner.status !== 'approved') {
            throw new ForbiddenException('Tài khoản đối tác của bạn không hợp lệ hoặc chưa được duyệt.');
        }
        return partner;
    }

    // --- Category Management (System Admin only) ---

    async createCategory(dto: { name: string, slug: string, description?: string }): Promise<Category> {
        const newCategory = this.categoryRepository.create(dto);
        return this.categoryRepository.save(newCategory);
    }

    async findAllCategories(): Promise<Category[]> {
        return this.categoryRepository.find();
    }

    // --- Solution Management (Admin & Partner) ---

    async createSolution(dto: any, user: User): Promise<Solution> {
        const category = await this.categoryRepository.findOneBy({ id: dto.categoryId });
        if (!category) {
            throw new NotFoundException(`Danh mục với ID ${dto.categoryId} không tồn tại.`);
        }

        const newSolutionData: Partial<Solution> = { ...dto, category };

        if (user.systemRole === 'PARTNER') {
            const partner = await this.getPartnerFromUser(user);
            newSolutionData.partner = partner;
        } else if (user.systemRole !== 'SYSTEM_ADMIN') {
            throw new UnauthorizedException('Bạn không có quyền tạo giải pháp.');
        }

        const newSolution = this.solutionRepository.create(newSolutionData);
        return this.solutionRepository.save(newSolution);
    }

    async updateSolution(solutionId: string, dto: any, user: User): Promise<Solution> {
        const solution = await this.findSolutionById(solutionId);
        
        if (user.systemRole === 'PARTNER') {
            const partner = await this.getPartnerFromUser(user);
            if (solution.partner?.id !== partner.id) {
                throw new ForbiddenException('Bạn không có quyền chỉnh sửa giải pháp này.');
            }
        } else if (user.systemRole !== 'SYSTEM_ADMIN') {
            throw new UnauthorizedException('Bạn không có quyền chỉnh sửa giải pháp.');
        }

        // Update category if provided
        if (dto.categoryId && dto.categoryId !== solution.category.id) {
            const category = await this.categoryRepository.findOneBy({ id: dto.categoryId });
            if (!category) throw new NotFoundException(`Danh mục với ID ${dto.categoryId} không tồn tại.`);
            solution.category = category;
        }
        
        const { categoryId, ...updateData } = dto;
        Object.assign(solution, updateData);
        return this.solutionRepository.save(solution);
    }

    async findAllSolutions(): Promise<Solution[]> {
        return this.solutionRepository.find({ where: { isActive: true }, relations: ['category', 'partner'] });
    }

    async findSolutionById(id: string): Promise<Solution> {
        const solution = await this.solutionRepository.findOne({ where: { id }, relations: ['category', 'partner'] });
        if (!solution) {
            throw new NotFoundException(`Giải pháp với ID ${id} không tồn tại.`);
        }
        return solution;
    }

    // --- Plan Management (Admin & Partner) ---

    async createPlan(solutionId: string, dto: any, user: User): Promise<Plan> {
        const solution = await this.findSolutionById(solutionId);

        if (user.systemRole === 'PARTNER') {
            const partner = await this.getPartnerFromUser(user);
            if (solution.partner?.id !== partner.id) {
                 throw new ForbiddenException('Bạn không có quyền thêm gói cho giải pháp này.');
            }
        } else if (user.systemRole !== 'SYSTEM_ADMIN') {
            throw new UnauthorizedException('Bạn không có quyền tạo gói cước.');
        }
        
        const newPlan = this.planRepository.create({ ...dto, solution });
        return this.planRepository.save(newPlan);
    }
    
    async updatePlan(planId: string, dto: any, user: User): Promise<Plan> {
        const plan = await this.planRepository.findOne({ where: { id: planId }, relations: ['solution', 'solution.partner'] });
        if (!plan) throw new NotFoundException(`Gói cước với ID ${planId} không tồn tại.`);

        if (user.systemRole === 'PARTNER') {
            const partner = await this.getPartnerFromUser(user);
            if (plan.solution.partner?.id !== partner.id) {
                throw new ForbiddenException('Bạn không có quyền chỉnh sửa gói cước này.');
            }
        } else if (user.systemRole !== 'SYSTEM_ADMIN') {
             throw new UnauthorizedException('Bạn không có quyền chỉnh sửa gói cước.');
        }

        Object.assign(plan, dto);
        return this.planRepository.save(plan);
    }


    async findPlansBySolution(solutionId: string): Promise<Plan[]> {
        return this.planRepository.find({
            where: { 
                solution: { id: solutionId },
                isActive: true 
            },
            order: { price: 'ASC' }
        });
    }
}