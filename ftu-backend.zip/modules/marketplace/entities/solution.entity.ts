// File: ftu-backend/src/modules/marketplace/entities/solution.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Category } from './category.entity';
import { Partner } from '../../partners/entities/partner.entity';

@Entity('marketplace_solutions')
export class Solution {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Column()
    name: string;

    @Column({ type: 'text' })
    tagline: string;

    @Column({ type: 'text' })
    description: string;

    @Column({ name: 'logo_url', nullable: true })
    logoUrl: string;
    
    @Column({ name: 'webhook_endpoint', nullable: true })
    webhookEndpoint: string;

    @ManyToOne(() => Category, { eager: true })
    @JoinColumn({ name: 'category_id' })
    category: Category;

    // Đối với sản phẩm nội bộ, trường này có thể là null
    @ManyToOne(() => Partner, partner => partner.solutions, { nullable: true })
    @JoinColumn({ name: 'partner_id' })
    partner: Partner; 

    /**
     * === CỘT MỚI ĐƯỢC BỔ SUNG ===
     * Dùng để phân biệt giải pháp của Partner (false) và sản phẩm nội bộ của FTU (true).
     * Ví dụ: Các gói Membership sẽ là một "Solution" có isInternal = true.
     */
    @Column({ name: 'is_internal', default: false })
    isInternal: boolean;

    @Column({ default: true })
    isActive: boolean;

    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;

    @UpdateDateColumn({ name: 'updated_at' })
    updatedAt: Date;
}