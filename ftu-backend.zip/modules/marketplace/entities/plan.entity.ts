// File: ftu-backend/src/modules/marketplace/entities/plan.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { Solution } from './solution.entity';

@Entity('marketplace_plans')
export class Plan {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @ManyToOne(() => Solution, { onDelete: 'CASCADE' })
    @JoinColumn({ name: 'solution_id' })
    solution: Solution;

    @Column()
    name: string; // Ví dụ: "Gói Chuyên nghiệp"

    @Column({ type: 'decimal', precision: 12, scale: 2 })
    price: number;

    @Column({ name: 'billing_cycle', type: 'enum', enum: ['monthly', 'yearly'] })
    billingCycle: 'monthly' | 'yearly';

    @Column({ type: 'jsonb' })
    features: string[]; // Ví dụ: ["10 Users", "AI Analytics", "5GB Storage"]
    
    @Column({ default: true })
    isActive: boolean;
}