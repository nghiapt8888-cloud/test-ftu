// File: ftu-backend/src/modules/marketplace/entities/category.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, Unique } from 'typeorm';

@Entity('marketplace_categories')
@Unique(['slug'])
export class Category {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Column()
    name: string; // Tên danh mục, ví dụ: "Quản lý Bán hàng"

    @Column({ unique: true })
    slug: string; // "quan-ly-ban-hang"

    @Column({ nullable: true })
    description: string;
}