// File: ftu-backend/src/modules/accounts/accounts.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from './entities/user.entity';
import { AccountsService } from './accounts.service';
import { AccountsController } from './accounts.controller';

@Module({
  imports: [TypeOrmModule.forFeature([User])],
  providers: [AccountsService],
  controllers: [AccountsController],
  exports: [AccountsService], // Xuất AccountsService để các module khác (như Auth) có thể sử dụng
})
export class AccountsModule {}