// File: ftu-backend/src/modules/accounts/accounts.service.ts
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, EntityManager } from 'typeorm';
import { User } from './entities/user.entity';
import * as bcrypt from 'bcrypt';

@Injectable()
export class AccountsService {
    constructor(
        @InjectRepository(User)
        private readonly userRepository: Repository<User>,
    ) {}

    async findByEmail(email: string): Promise<User | null> {
        return this.userRepository.findOne({ where: { email } });
    }

    async findById(id: number): Promise<User | null> {
        return this.userRepository.findOne({ where: { id } });
    }

    async create(data: Partial<User>): Promise<User> {
        const hashedPassword = await bcrypt.hash(data.password, 10);
        const newUser = this.userRepository.create({
            ...data,
            password: hashedPassword,
        });
        return this.userRepository.save(newUser);
    }

    /**
     * === HÀM MỚI ĐƯỢC BỔ SUNG ===
     * Cập nhật vai trò hệ thống của một người dùng.
     * Có thể hoạt động bên trong một transaction có sẵn.
     */
    async updateSystemRole(userId: number, newRole: 'SYSTEM_ADMIN' | 'PARTNER' | 'USER', manager?: EntityManager): Promise<User> {
        const repository = manager ? manager.getRepository(User) : this.userRepository;
        const user = await repository.findOneBy({ id: userId });
        if (!user) {
            throw new NotFoundException(`Không tìm thấy người dùng với ID ${userId}`);
        }
        user.systemRole = newRole;
        return repository.save(user);
    }
}