// File: ftu-backend/src/modules/accounts/entities/user.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('users')
export class User {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ unique: true })
    email: string;

    @Column()
    password: string;

    @Column({ name: 'first_name', nullable: true })
    firstName: string;

    @Column({ name: 'last_name', nullable: true })
    lastName: string;

    @Column({ nullable: true })
    phone: string;

    @Column({ name: 'avatar_url', nullable: true })
    avatarUrl: string;

    @Column({ name: 'last_login_at', type: 'timestamp', nullable: true })
    lastLoginAt: Date;
    
    // Thêm một trường để xác định vai trò ở cấp độ hệ thống
    @Column({
        name: 'system_role',
        type: 'enum',
        enum: ['SYSTEM_ADMIN', 'PARTNER', 'USER'],
        default: 'USER',
    })
    systemRole: 'SYSTEM_ADMIN' | 'PARTNER' | 'USER';

    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;

    @UpdateDateColumn({ name: 'updated_at' })
    updatedAt: Date;
}