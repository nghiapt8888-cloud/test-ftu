// File: ftu-backend/src/modules/support/support.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SupportService } from './support.service';
import { SupportController } from './support.controller';
import { Ticket } from './entities/ticket.entity';
import { TicketReply } from './entities/ticket-reply.entity';
import { AuthModule } from '../../core/auth/auth.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Ticket, TicketReply]),
    AuthModule, // Để sử dụng các Guard
  ],
  controllers: [SupportController],
  providers: [SupportService],
})
export class SupportModule {}