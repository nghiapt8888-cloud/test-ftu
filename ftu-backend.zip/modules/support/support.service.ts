// File: ftu-backend/src/modules/support/support.service.ts
import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Ticket } from './entities/ticket.entity';
import { TicketReply } from './entities/ticket-reply.entity';
import { User } from '../accounts/entities/user.entity';
import { CreateTicketDto } from './dto/create-ticket.dto';
import { CreateReplyDto } from './dto/create-reply.dto';

@Injectable()
export class SupportService {
  constructor(
    @InjectRepository(Ticket)
    private readonly ticketRepository: Repository<Ticket>,
    @InjectRepository(TicketReply)
    private readonly ticketReplyRepository: Repository<TicketReply>,
  ) {}

  // --- Cho người dùng ---
  async createTicket(dto: CreateTicketDto, requester: User): Promise<Ticket> {
    const ticket = this.ticketRepository.create({
      ...dto,
      requester,
    });
    return this.ticketRepository.save(ticket);
  }

  async findMyTickets(requesterId: number): Promise<Ticket[]> {
    return this.ticketRepository.find({
      where: { requester: { id: requesterId } },
      order: { updatedAt: 'DESC' },
    });
  }

  async findTicketByIdForUser(ticketId: string, userId: number): Promise<Ticket> {
    const ticket = await this.ticketRepository.findOne({
        where: { id: ticketId },
        relations: ['replies', 'replies.author'],
    });
    if (!ticket) {
      throw new NotFoundException('Không tìm thấy ticket.');
    }
    if (ticket.requester.id !== userId) {
      throw new ForbiddenException('Bạn không có quyền xem ticket này.');
    }
    return ticket;
  }

  async addReplyFromUser(ticketId: string, dto: CreateReplyDto, author: User): Promise<TicketReply> {
    const ticket = await this.findTicketByIdForUser(ticketId, author.id);
    const reply = this.ticketReplyRepository.create({
      ...dto,
      ticket,
      author,
    });
    // Cập nhật lại thời gian của ticket chính
    ticket.updatedAt = new Date();
    await this.ticketRepository.save(ticket);
    return this.ticketReplyRepository.save(reply);
  }

  // --- Cho Admin ---
  async findAllTickets(): Promise<Ticket[]> {
      return this.ticketRepository.find({
          order: { updatedAt: 'DESC' }
      });
  }

  async findTicketByIdForAdmin(ticketId: string): Promise<Ticket> {
      const ticket = await this.ticketRepository.findOne({
          where: { id: ticketId },
          relations: ['replies', 'replies.author', 'assignee'],
      });
      if (!ticket) throw new NotFoundException('Không tìm thấy ticket.');
      return ticket;
  }

   async addReplyFromAdmin(ticketId: string, dto: CreateReplyDto, author: User): Promise<TicketReply> {
    const ticket = await this.findTicketByIdForAdmin(ticketId);
    const reply = this.ticketReplyRepository.create({
      ...dto,
      ticket,
      author,
    });
    ticket.updatedAt = new Date();
    await this.ticketRepository.save(ticket);
    return this.ticketReplyRepository.save(reply);
  }
}