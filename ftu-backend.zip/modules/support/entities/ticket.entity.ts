// File: ftu-backend/src/modules/support/entities/ticket.entity.ts
import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  OneToMany,
} from 'typeorm';
import { User } from '../../accounts/entities/user.entity';
import { TicketReply } from './ticket-reply.entity';

export type TicketStatus = 'open' | 'in_progress' | 'closed';
export type TicketPriority = 'low' | 'medium' | 'high' | 'urgent';

@Entity('support_tickets')
export class Ticket {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  title: string;

  @Column({ type: 'text' })
  description: string;

  @Column({
    type: 'enum',
    enum: ['open', 'in_progress', 'closed'],
    default: 'open',
  })
  status: TicketStatus;

  @Column({
    type: 'enum',
    enum: ['low', 'medium', 'high', 'urgent'],
    default: 'medium',
  })
  priority: TicketPriority;

  // Người dùng đã tạo ticket này
  @ManyToOne(() => User, { eager: true }) // eager: true để luôn lấy thông tin user khi query ticket
  @JoinColumn({ name: 'requester_id' })
  requester: User;

  // Admin được gán để xử lý ticket này
  @ManyToOne(() => User, { nullable: true })
  @JoinColumn({ name: 'assignee_id' })
  assignee: User;
  
  @OneToMany(() => TicketReply, (reply) => reply.ticket)
  replies: TicketReply[];

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}