// File: ftu-backend/src/modules/support/dto/create-reply.dto.ts
import { IsNotEmpty, IsString, MinLength } from 'class-validator';

export class CreateReplyDto {
  @IsNotEmpty({ message: 'Nội dung trả lời không được để trống.' })
  @IsString()
  @MinLength(1, { message: 'Nội dung trả lời không được để trống.' })
  message: string;
}