// File: ftu-backend/src/modules/support/dto/create-ticket.dto.ts
import { IsNotEmpty, IsString, MinLength } from 'class-validator';

export class CreateTicketDto {
  @IsNotEmpty({ message: 'Tiêu đề không được để trống.' })
  @IsString()
  @MinLength(5, { message: 'Tiêu đề phải có ít nhất 5 ký tự.' })
  title: string;

  @IsNotEmpty({ message: 'Nội dung không được để trống.' })
  @IsString()
  @MinLength(10, { message: 'Nội dung phải có ít nhất 10 ký tự.' })
  description: string;
}