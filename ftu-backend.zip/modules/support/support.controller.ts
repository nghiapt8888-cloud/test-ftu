// File: ftu-backend/src/modules/support/support.controller.ts
import { Controller, Get, Post, Body, Param, UseGuards, Req, ParseUUIDPipe } from '@nestjs/common';
import { JwtAuthGuard } from '../../core/auth/guards/jwt-auth.guard';
import { SystemAdminGuard } from '../../core/auth/guards/system-admin.guard';
import { SupportService } from './support.service';
import { CreateTicketDto } from './dto/create-ticket.dto';
import { CreateReplyDto } from './dto/create-reply.dto';
import { User } from '../accounts/entities/user.entity';

@Controller('support')
@UseGuards(JwtAuthGuard)
export class SupportController {
  constructor(private readonly supportService: SupportService) {}

  // --- User Routes ---

  @Post('tickets')
  createTicket(@Body() createTicketDto: CreateTicketDto, @Req() req: { user: User }) {
    return this.supportService.createTicket(createTicketDto, req.user);
  }

  @Get('tickets')
  getMyTickets(@Req() req: { user: User }) {
    return this.supportService.findMyTickets(req.user.id);
  }

  @Get('tickets/:id')
  getTicketDetails(@Param('id', ParseUUIDPipe) id: string, @Req() req: { user: User }) {
    // Service sẽ kiểm tra quyền sở hữu
    return this.supportService.findTicketByIdForUser(id, req.user.id);
  }
  
  @Post('tickets/:id/replies')
  addReply(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() createReplyDto: CreateReplyDto,
    @Req() req: { user: User }
  ) {
    return this.supportService.addReplyFromUser(id, createReplyDto, req.user);
  }


  // --- Admin Routes ---
  
  @Get('admin/tickets')
  @UseGuards(SystemAdminGuard)
  getAllTickets() {
      return this.supportService.findAllTickets();
  }

  @Get('admin/tickets/:id')
  @UseGuards(SystemAdminGuard)
  getTicketDetailsForAdmin(@Param('id', ParseUUIDPipe) id: string) {
      return this.supportService.findTicketByIdForAdmin(id);
  }

  @Post('admin/tickets/:id/replies')
  @UseGuards(SystemAdminGuard)
  addReplyAsAdmin(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() createReplyDto: CreateReplyDto,
    @Req() req: { user: User }
  ) {
    return this.supportService.addReplyFromAdmin(id, createReplyDto, req.user);
  }
}