// File: ftu-backend/src/modules/affiliates/affiliates.controller.ts
import { Controller, Post, Get, UseGuards, Req } from '@nestjs/common';
import { AffiliatesService } from './affiliates.service';
import { JwtAuthGuard } from '../../core/auth/guards/jwt-auth.guard';
import { User } from '../accounts/entities/user.entity';

@UseGuards(JwtAuthGuard)
@Controller('affiliates')
export class AffiliatesController {
    constructor(private readonly affiliatesService: AffiliatesService) {}

    @Post('register')
    register(@Req() req: { user: User }) {
        return this.affiliatesService.registerAffiliate(req.user);
    }

    @Get('profile')
    getProfile(@Req() req: { user: User }) {
        return this.affiliatesService.getMyAffiliateProfile(req.user);
    }

    @Get('commissions')
    getCommissions(@Req() req: { user: User }) {
        return this.affiliatesService.getMyCommissions(req.user);
    }
}