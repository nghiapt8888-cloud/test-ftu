// File: ftu-backend/src/modules/affiliates/entities/commission.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, CreateDateColumn } from 'typeorm';
import { Affiliate } from './affiliate.entity';
import { User } from '../../accounts/entities/user.entity';
import { Subscription } from '../../billing/entities/subscription.entity';

export type CommissionStatus = 'pending' | 'approved' | 'paid' | 'rejected';

@Entity('affiliate_commissions')
export class Commission {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @ManyToOne(() => Affiliate)
    @JoinColumn({ name: 'affiliate_id' })
    affiliate: Affiliate;

    // Người dùng được giới thiệu (người đã đăng ký và mua hàng)
    @ManyToOne(() => User)
    @JoinColumn({ name: 'referred_user_id' })
    referredUser: User;

    // Gói cước đã được mua, để biết được hoa hồng đến từ đâu
    @ManyToOne(() => Subscription)
    @JoinColumn({ name: 'subscription_id' })
    subscription: Subscription;

    @Column({ type: 'decimal', precision: 12, scale: 2 })
    amount: number; // Số tiền hoa hồng

    @Column({ type: 'enum', enum: ['pending', 'approved', 'paid', 'rejected'], default: 'pending' })
    status: CommissionStatus;

    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;
}