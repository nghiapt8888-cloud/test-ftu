// File: ftu-backend/src/modules/affiliates/entities/affiliate.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, OneToOne, JoinColumn, CreateDateColumn } from 'typeorm';
import { User } from '../../accounts/entities/user.entity';

@Entity('affiliates')
export class Affiliate {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @OneToOne(() => User)
    @JoinColumn({ name: 'user_id' })
    user: User;

    @Column({ name: 'referral_code', unique: true })
    referralCode: string; // Mã giới thiệu duy nhất, ví dụ: "REF-USER123"

    @Column({ name: 'total_referrals', default: 0 })
    totalReferrals: number; // Tổng số người đã đăng ký qua link

    @Column({ name: 'total_commissions', type: 'decimal', precision: 12, scale: 2, default: 0.0 })
    totalCommissions: number; // Tổng hoa hồng kiếm được

    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;
}