// File: ftu-backend/src/modules/affiliates/affiliates.service.ts
import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Affiliate } from './entities/affiliate.entity';
import { Commission } from './entities/commission.entity';
import { User } from '../accounts/entities/user.entity';
import { Subscription } from '../billing/entities/subscription.entity';
import { MembershipsService } from '../memberships/memberships.service'; // <-- IMPORT MỚI
import { NotificationsService } from '../notifications/notifications.service'; // <-- IMPORT MỚI
import { Organization } from '../organizations/entities/organization.entity';

@Injectable()
export class AffiliatesService {
    constructor(
        @InjectRepository(Affiliate) private readonly affiliateRepository: Repository<Affiliate>,
        @InjectRepository(Commission) private readonly commissionRepository: Repository<Commission>,
        private readonly membershipsService: MembershipsService, // <-- INJECT SERVICE MỚI
        private readonly notificationsService: NotificationsService, // <-- INJECT SERVICE MỚI
    ) {}

    /**
     * Cho phép một người dùng đăng ký tham gia chương trình affiliate.
     */
    async registerAffiliate(user: User): Promise<Affiliate> {
        const existing = await this.affiliateRepository.findOne({ where: { user: { id: user.id } } });
        if (existing) {
            throw new ConflictException('Bạn đã là một thành viên tiếp thị liên kết.');
        }

        const referralCode = `REF-${user.id}${Date.now().toString().slice(-4)}`;

        const newAffiliate = this.affiliateRepository.create({
            user,
            referralCode,
        });

        return this.affiliateRepository.save(newAffiliate);
    }

    /**
     * Lấy thông tin affiliate của người dùng hiện tại.
     */
    async getMyAffiliateProfile(user: User): Promise<Affiliate> {
        const affiliate = await this.affiliateRepository.findOne({ where: { user: { id: user.id } } });
        if (!affiliate) {
            throw new NotFoundException('Bạn chưa đăng ký chương trình tiếp thị liên kết.');
        }
        return affiliate;
    }

    /**
     * Lấy lịch sử hoa hồng của người dùng hiện tại.
     */
    async getMyCommissions(user: User): Promise<Commission[]> {
        const affiliate = await this.getMyAffiliateProfile(user);
        return this.commissionRepository.find({
            where: { affiliate: { id: affiliate.id } },
            order: { createdAt: 'DESC' },
            relations: ['referredUser', 'subscription', 'subscription.plan'],
        });
    }

    /**
     * (Hàm nội bộ) Ghi nhận một khoản hoa hồng mới.
     * Được gọi bởi BillingService sau khi một thanh toán thành công.
     */
    async recordCommission(subscription: Subscription, referredByUser: User): Promise<void> {
        const affiliate = await this.affiliateRepository.findOne({ where: { user: { id: referredByUser.id } }, relations: ['user.organization'] });
        if (!affiliate) {
            console.warn(`Attempted to record commission for a non-affiliate user ID: ${referredByUser.id}`);
            return;
        }

        // Tỷ lệ hoa hồng cơ bản
        let commissionRate = 0.1; // Giả định hoa hồng 10%

        // --- LOGIC MỚI: KIỂM TRA VÀ ÁP DỤNG QUYỀN LỢI THÀNH VIÊN ---
        // Giả định tổ chức của affiliate là nơi đăng ký gói membership
        const affiliateOrg = (affiliate.user as any).organization as Organization;
        if (affiliateOrg) {
            const activeMembership = await this.membershipsService.getActiveMembershipForOrg(affiliateOrg.id);
            if (activeMembership && activeMembership.plan.benefits.commissionBoost) {
                commissionRate += parseFloat(activeMembership.plan.benefits.commissionBoost);
            }
        }
        
        const commissionAmount = subscription.plan.price * commissionRate;

        const newCommission = this.commissionRepository.create({
            affiliate,
            referredUser: subscription.organization.owner, // Người mua hàng
            subscription,
            amount: commissionAmount,
            status: 'pending',
        });
        
        await this.commissionRepository.save(newCommission);

        // Cập nhật tổng số lượt giới thiệu và tổng hoa hồng
        affiliate.totalReferrals += 1;
        affiliate.totalCommissions = Number(affiliate.totalCommissions) + commissionAmount;
        await this.affiliateRepository.save(affiliate);
        
        // --- LOGIC MỚI: GỬI THÔNG BÁO CHO AFFILIATE ---
        await this.notificationsService.create(
            affiliate.user,
            'Bạn có hoa hồng mới!',
            `Bạn vừa nhận được ${commissionAmount.toLocaleString('vi-VN')}đ hoa hồng từ gói ${subscription.plan.name}.`,
            '/dashboard/affiliate' // Điều hướng đến trang affiliate
        );
    }
}