// File: ftu-backend/src/modules/notifications/notifications.service.ts
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Notification } from './entities/notification.entity';
import { User } from '../accounts/entities/user.entity';

@Injectable()
export class NotificationsService {
    constructor(
        @InjectRepository(Notification)
        private readonly notificationRepository: Repository<Notification>,
    ) {}

    /**
     * Hàm nội bộ để các service khác gọi và tạo thông báo mới.
     */
    async create(recipient: User, title: string, message: string, linkTo?: string): Promise<Notification> {
        const notification = this.notificationRepository.create({
            recipient,
            title,
            message,
            linkTo,
        });
        return this.notificationRepository.save(notification);
    }

    async findForUser(userId: number): Promise<Notification[]> {
        return this.notificationRepository.find({
            where: { recipient: { id: userId } },
            order: { createdAt: 'DESC' },
            take: 20, // Lấy 20 thông báo gần nhất
        });
    }

    async markAsRead(notificationId: string, userId: number): Promise<void> {
        await this.notificationRepository.update(
            { id: notificationId, recipient: { id: userId } },
            { isRead: true }
        );
    }
}