// File: ftu-backend/src/modules/notifications/entities/notification.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { User } from '../../accounts/entities/user.entity';

@Entity('notifications')
export class Notification {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @ManyToOne(() => User)
    @JoinColumn({ name: 'recipient_id' })
    recipient: User; // Người nhận thông báo

    @Column({ type: 'text' })
    title: string; // Tiêu đề thông báo, ví dụ: "Bạn có hoa hồng mới!"

    @Column({ type: 'text' })
    message: string; // Nội dung chi tiết

    @Column({ name: 'is_read', default: false })
    isRead: boolean;

    @Column({ name: 'link_to', nullable: true })
    linkTo: string; // Đường dẫn để điều hướng khi người dùng nhấp vào, ví dụ: "/dashboard/affiliate"

    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;
}