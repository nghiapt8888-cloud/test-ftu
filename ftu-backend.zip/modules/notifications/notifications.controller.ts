// File: ftu-backend/src/modules/notifications/notifications.controller.ts
import { Controller, Get, Patch, Param, UseGuards, Req, ParseUUIDPipe } from '@nestjs/common';
import { NotificationsService } from './notifications.service';
import { JwtAuthGuard } from '../../core/auth/guards/jwt-auth.guard';
import { User } from '../accounts/entities/user.entity';

@UseGuards(JwtAuthGuard)
@Controller('notifications')
export class NotificationsController {
    constructor(private readonly notificationsService: NotificationsService) {}

    @Get()
    findMyNotifications(@Req() req: { user: User }) {
        return this.notificationsService.findForUser(req.user.id);
    }

    @Patch(':id/read')
    markAsRead(@Param('id', ParseUUIDPipe) id: string, @Req() req: { user: User }) {
        return this.notificationsService.markAsRead(id, req.user.id);
    }
}