// File: ftu-backend/src/modules/partners/entities/partner.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, OneToOne, JoinColumn, OneToMany } from 'typeorm';
import { User } from '../../accounts/entities/user.entity';
import { Solution } from '../../marketplace/entities/solution.entity';

export type PartnerStatus = 'pending_approval' | 'approved' | 'rejected' | 'suspended';

@Entity('partners')
export class Partner {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    // Mỗi partner profile phải được liên kết với một user duy nhất
    @OneToOne(() => User)
    @JoinColumn({ name: 'user_id' })
    user: User;

    @Column({ name: 'brand_name' })
    brandName: string; // Tên thương hiệu/cửa hàng của đối tác

    @Column({ nullable: true })
    website: string;

    @Column({ name: 'support_email', nullable: true })
    supportEmail: string; // Email hỗ trợ khách hàng của đối tác

    @Column({
        type: 'enum',
        enum: ['pending_approval', 'approved', 'rejected', 'suspended'],
        default: 'pending_approval',
    })
    status: PartnerStatus;

    // Một đối tác có thể có nhiều giải pháp
    @OneToMany(() => Solution, solution => solution.partner)
    solutions: Solution[];

    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;

    @UpdateDateColumn({ name: 'updated_at' })
    updatedAt: Date;
}