// File: ftu-backend/src/modules/partners/partners.controller.ts
import { Controller, Post, Get, Body, UseGuards, Req } from '@nestjs/common';
import { JwtAuthGuard } from '../../core/auth/guards/jwt-auth.guard';
import { User } from '../accounts/entities/user.entity';
import { PartnersService } from './partners.service';
import { PartnerApplicationDto } from './dto/partner-application.dto';
// Sẽ tạo PartnerGuard ở bước sau
// import { PartnerGuard } from '../../core/auth/guards/partner.guard'; 

@UseGuards(JwtAuthGuard) // Yêu cầu đăng nhập cho tất cả các route trong controller này
@Controller('partners')
export class PartnersController {
    constructor(private readonly partnersService: PartnersService) {}

    @Post('apply')
    applyAsPartner(
        @Req() req: { user: User },
        @Body() applicationDto: PartnerApplicationDto
    ) {
        return this.partnersService.applyAsPartner(req.user, applicationDto);
    }
    
    @Get('me')
    // @UseGuards(PartnerGuard) // Sau này sẽ dùng Guard này để đảm bảo chỉ partner mới vào được
    getMyProfile(@Req() req: { user: User }) {
        return this.partnersService.getMyProfile(req.user);
    }

    // TODO: Thêm endpoint PATCH /me để partner tự cập nhật thông tin
}