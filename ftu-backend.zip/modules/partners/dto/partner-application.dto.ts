// File: ftu-backend/src/modules/partners/dto/partner-application.dto.ts
import { IsString, IsNotEmpty, IsOptional, IsUrl, IsEmail } from 'class-validator';

export class PartnerApplicationDto {
    @IsNotEmpty({ message: 'Tên thương hiệu không được để trống.' })
    @IsString()
    brandName: string;

    @IsOptional()
    @IsUrl({}, { message: 'Website không hợp lệ.' })
    website?: string;

    @IsOptional()
    @IsEmail({}, { message: 'Email hỗ trợ không hợp lệ.'})
    supportEmail?: string;
}