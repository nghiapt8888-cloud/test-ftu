// File: ftu-backend/src/modules/partners/partners.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Partner } from './entities/partner.entity';
import { PartnersController } from './partners.controller';
import { PartnersService } from './partners.service';
import { AuthModule } from '../../core/auth/auth.module';
import { AccountsModule } from '../accounts/accounts.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Partner]),
    AuthModule,
    AccountsModule, // Cần thiết để cập nhật systemRole cho User
  ],
  controllers: [PartnersController],
  providers: [PartnersService],
})
export class PartnersModule {}