// File: ftu-backend/src/modules/partners/partners.service.ts
import { Injectable, ConflictException, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { Partner, PartnerStatus } from './entities/partner.entity';
import { User } from '../accounts/entities/user.entity';
import { AccountsService } from '../accounts/accounts.service';
import { PartnerApplicationDto } from './dto/partner-application.dto';

@Injectable()
export class PartnersService {
    constructor(
        private readonly dataSource: DataSource,
        @InjectRepository(Partner)
        private readonly partnerRepository: Repository<Partner>,
        private readonly accountsService: AccountsService,
    ) {}

    /**
     * Xử lý đơn đăng ký trở thành đối tác của người dùng.
     * Cập nhật vai trò của User và tạo Profile Partner trong cùng một transaction.
     */
    async applyAsPartner(user: User, applicationDto: PartnerApplicationDto): Promise<Partner> {
        // Kiểm tra xem user này đã là partner hoặc có đơn đăng ký chưa
        const existingPartner = await this.partnerRepository.findOne({ where: { user: { id: user.id } } });
        if (existingPartner) {
            throw new ConflictException('Bạn đã có một hồ sơ đối tác.');
        }

        if (user.systemRole !== 'USER') {
           throw new ConflictException('Vai trò hiện tại của bạn không thể đăng ký làm đối tác.');
        }

        return this.dataSource.transaction(async manager => {
            // 1. Cập nhật vai trò của user thành PARTNER
            await this.accountsService.updateSystemRole(user.id, 'PARTNER', manager);

            // 2. Tạo hồ sơ Partner mới
            const newPartner = manager.create(Partner, {
                ...applicationDto,
                user,
                status: 'pending_approval', // Mặc định chờ duyệt
            });

            return manager.save(newPartner);
        });
    }

    /**
     * Lấy hồ sơ đối tác của người dùng đang đăng nhập.
     */
    async getMyProfile(user: User): Promise<Partner> {
        const partnerProfile = await this.partnerRepository.findOne({ where: { user: { id: user.id } } });
        if (!partnerProfile) {
            throw new NotFoundException('Không tìm thấy hồ sơ đối tác.');
        }
        return partnerProfile;
    }
    
    /**
     * === CÁC HÀM DÀNH CHO ADMIN ===
     */
   
    /**
     * Lấy danh sách tất cả đối tác.
     * Bao gồm thông tin người dùng liên kết.
     */
    async findAllPartners(): Promise<Partner[]> {
        return this.partnerRepository.find({
            relations: ['user'],
            order: { createdAt: 'DESC' },
        });
    }

    /**
     * Lấy chi tiết một đối tác bằng ID.
     * Bao gồm thông tin người dùng và các giải pháp đã tạo.
     */
    async findPartnerById(partnerId: string): Promise<Partner> {
        const partner = await this.partnerRepository.findOne({
            where: { id: partnerId },
            relations: ['user', 'solutions'],
        });
        if (!partner) {
            throw new NotFoundException(`Không tìm thấy đối tác với ID ${partnerId}.`);
        }
        return partner;
    }

    /**
     * Cập nhật trạng thái của một đối tác.
     * Ví dụ: từ 'pending_approval' sang 'active' hoặc 'rejected'.
     */
    async updatePartnerStatus(partnerId: string, status: PartnerStatus): Promise<Partner> {
        const partner = await this.findPartnerById(partnerId);
        partner.status = status;
        // TODO: Gửi email/thông báo cho đối tác về việc thay đổi trạng thái
        return this.partnerRepository.save(partner);
    }
}