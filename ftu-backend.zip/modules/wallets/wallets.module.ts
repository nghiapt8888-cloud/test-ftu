// File: ftu-backend/src/modules/wallets/wallets.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WalletsService } from './wallets.service';
import { WalletsController } from './wallets.controller';
import { Wallet } from './entities/wallet.entity';
import { Transaction } from './entities/transaction.entity';
import { AuthModule } from '../../core/auth/auth.module';
import { OrganizationsModule } from '../organizations/organizations.module';
import { GatewaysModule } from '../../platform_admin/payment_gateways/gateways.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Wallet, Transaction]),
    AuthModule,
    OrganizationsModule,
    GatewaysModule,
  ],
  controllers: [WalletsController],
  providers: [WalletsService],
  exports: [WalletsService],
})
export class WalletsModule {}