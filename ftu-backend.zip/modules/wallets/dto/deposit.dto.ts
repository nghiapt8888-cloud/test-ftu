// File: ftu-backend/src/modules/wallets/dto/deposit.dto.ts
import { IsNumber, IsUUID, IsNotEmpty, Min } from 'class-validator';

export class DepositDto {
    @IsNotEmpty({ message: 'Số tiền nạp không được để trống.' })
    @IsNumber({}, { message: 'Số tiền phải là một con số.' })
    @Min(10000, { message: 'Số tiền nạp tối thiểu là 10,000đ.' }) // Ví dụ: đặt một giới hạn tối thiểu
    amount: number;

    @IsNotEmpty({ message: 'ID của Tổ chức không được để trống.' })
    @IsUUID('4')
    organizationId: string;

    @IsNotEmpty({ message: 'Cổng thanh toán không được để trống.' })
    @IsUUID('4')
    gatewayId: string; // ID của cổng thanh toán (Momo, VNPay...) mà người dùng đã chọn
}