// File: ftu-backend/src/modules/wallets/dto/transfer-funds.dto.ts
import { IsNumber, IsString, IsUUID, Min, IsNotEmpty } from 'class-validator';

export class TransferFundsDto {
    @IsNotEmpty({ message: 'ID tổ chức gửi không được để trống.' })
    @IsUUID('4')
    fromOrganizationId: string;

    @IsNotEmpty({ message: 'Email hoặc ID tổ chức nhận không được để trống.' })
    @IsString()
    recipientIdentifier: string; // Có thể là email của owner hoặc ID của tổ chức nhận

    @IsNotEmpty({ message: 'Số tiền không được để trống.' })
    @IsNumber({}, { message: 'Số tiền phải là một con số.' })
    @Min(1000, { message: 'Số tiền chuyển tối thiểu là 1,000 Fcoin.' })
    amount: number;
    
    @IsString()
    @IsNotEmpty({ message: 'Nội dung chuyển khoản không được để trống.' })
    description: string;
}