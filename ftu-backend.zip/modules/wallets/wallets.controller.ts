// File: ftu-backend/src/modules/wallets/wallets.controller.ts
import { Controller, Post, Body, Get, UseGuards, Req, Query, ParseUUIDPipe } from '@nestjs/common';
import { WalletsService } from './wallets.service';
import { JwtAuthGuard } from '../../core/auth/guards/jwt-auth.guard';
import { OrganizationMemberGuard } from '../../core/auth/guards/organization-member.guard';
import { User } from '../accounts/entities/user.entity';
import { DepositDto } from './dto/deposit.dto';
import { TransferFundsDto } from './dto/transfer-funds.dto';

@UseGuards(JwtAuthGuard) // Bảo vệ tất cả các endpoint trong controller này
@Controller('wallets')
export class WalletsController {
    constructor(private readonly walletsService: WalletsService) {}

    // Endpoint GET /public/gateways đã được XÓA BỎ khỏi đây.
    // Logic này giờ đã được chuyển sang GatewaysController.

    @UseGuards(OrganizationMemberGuard)
    @Get()
    getWallet(@Query('organizationId', ParseUUIDPipe) organizationId: string) {
        return this.walletsService.getWalletByOrgId(organizationId);
    }
    
    @UseGuards(OrganizationMemberGuard)
    @Get('transactions')
    getTransactions(@Query('organizationId', ParseUUIDPipe) organizationId: string) {
        return this.walletsService.getTransactionsByOrgId(organizationId);
    }

    @UseGuards(OrganizationMemberGuard)
    @Post('deposit')
    initiateDeposit(@Body() depositDto: DepositDto, @Req() req: { user: User }) {
        return this.walletsService.initiateDeposit(depositDto, req.user);
    }

    /**
     * Endpoint cho P2P Transfer
     */
    @UseGuards(OrganizationMemberGuard) // Yêu cầu phải thuộc tổ chức gửi tiền
    @Post('transfer')
    transferFunds(@Body() transferDto: TransferFundsDto, @Req() req: { user: User }) {
        // Guard sẽ kiểm tra quyền của user trên fromOrganizationId (trong transferDto)
        return this.walletsService.transferFunds(transferDto, req.user);
    }
}