// File: ftu-backend/src/modules/wallets/entities/transaction.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Wallet } from './wallet.entity';
import { User } from '../../accounts/entities/user.entity';

export type TransactionType = 'deposit' | 'purchase' | 'withdrawal' | 'refund' | 'p2p_sent' | 'p2p_received' | 'affiliate_payout';

@Entity('wallet_transactions')
export class Transaction {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @ManyToOne(() => Wallet)
    @JoinColumn({ name: 'wallet_id' })
    wallet: Wallet;

    @Column({
        type: 'enum',
        enum: ['deposit', 'purchase', 'withdrawal', 'refund', 'p2p_sent', 'p2p_received', 'affiliate_payout'],
    })
    type: TransactionType;

    @Column({ type: 'decimal', precision: 18, scale: 4 })
    amount: number;

    @Column({ name: 'balance_after', type: 'decimal', precision: 18, scale: 4 })
    balanceAfter: number; // Số dư của ví sau khi giao dịch hoàn tất

    @Column({ type: 'text', nullable: true })
    description: string; // Mô tả giao dịch, ví dụ: "Mua gói CRM Pro" hoặc "Chuyển tiền cho tổ chức XYZ"

    @ManyToOne(() => User, { nullable: true })
    @JoinColumn({ name: 'initiated_by_user_id' })
    initiatedBy: User; // Người dùng đã thực hiện giao dịch

    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;
}