// File: ftu-backend/src/modules/wallets/entities/wallet.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, OneToOne, JoinColumn } from 'typeorm';
import { Organization } from '../../organizations/entities/organization.entity';

@Entity('wallets')
export class Wallet {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @OneToOne(() => Organization)
    @JoinColumn({ name: 'organization_id' })
    organization: Organization;

    @Column({
        type: 'decimal',
        precision: 18,
        scale: 4, // Hỗ trợ số thập phân để có độ chính xác cao
        default: 0.0,
    })
    balance: number;
}