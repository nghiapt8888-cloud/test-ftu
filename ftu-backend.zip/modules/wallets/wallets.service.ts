// File: ftu-backend/src/modules/wallets/wallets.service.ts
import { Injectable, NotFoundException, BadRequestException, ForbiddenException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource, EntityManager } from 'typeorm';
import { Wallet } from './entities/wallet.entity';
import { Transaction, TransactionType } from './entities/transaction.entity';
import { Organization } from '../organizations/entities/organization.entity';
import { User } from '../accounts/entities/user.entity';
import { DepositDto } from './dto/deposit.dto';
import { TransferFundsDto } from './dto/transfer-funds.dto';
import { GatewaysService } from '../../platform_admin/payment_gateways/gateways.service';
import { Gateway } from '../../platform_admin/payment_gateways/entities/gateway.entity';
import { OrganizationsService } from '../organizations/organizations.service';

@Injectable()
export class WalletsService {
    private readonly logger = new Logger(WalletsService.name);

    constructor(
        private readonly dataSource: DataSource,
        @InjectRepository(Wallet) private readonly walletRepository: Repository<Wallet>,
        @InjectRepository(Transaction) private readonly transactionRepository: Repository<Transaction>,
        private readonly gatewaysService: GatewaysService,
        private readonly organizationsService: OrganizationsService,
    ) {}

    async createWalletForOrganization(organization: Organization): Promise<Wallet> {
        const newWallet = this.walletRepository.create({ organization });
        return this.walletRepository.save(newWallet);
    }

    async getWalletByOrgId(organizationId: string): Promise<Wallet> {
        const wallet = await this.walletRepository.findOne({ where: { organization: { id: organizationId } } });
        if (!wallet) {
            throw new NotFoundException(`Không tìm thấy ví cho tổ chức ${organizationId}`);
        }
        return wallet;
    }
    
    async getTransactionsByOrgId(organizationId: string): Promise<Transaction[]> {
        const wallet = await this.getWalletByOrgId(organizationId);
        return this.transactionRepository.find({
            where: { wallet: { id: wallet.id } },
            order: { createdAt: 'DESC' },
            take: 50,
        });
    }

    /**
     * Lấy danh sách các cổng thanh toán đang hoạt động để hiển thị cho người dùng.
     */
    async getPublicGateways(): Promise<Gateway[]> {
        return this.gatewaysService.findAllActive();
    }

    /**
     * Khởi tạo một yêu cầu nạp tiền, đã được kiểm tra và xác thực.
     */
    async initiateDeposit(dto: DepositDto, user: User) {
        // 1. Xác thực cổng thanh toán
        const gateway = await this.gatewaysService.findOne(dto.gatewayId);
        if (!gateway.isActive) {
            throw new BadRequestException('Cổng thanh toán này hiện không hoạt động.');
        }

        this.logger.log(`User ${user.email} initiated deposit of ${dto.amount} for org ${dto.organizationId} via gateway ${gateway.gatewayName}`);
        
        // 2. TODO: Gọi đến "Adapter" của cổng thanh toán tương ứng để tạo link thanh toán
        // Dựa vào gateway.gatewayCode để chọn adapter phù hợp (MomoAdapter, VNPayAdapter...)
        // Ví dụ: 
        // let paymentUrl;
        // switch (gateway.gatewayCode) {
        //     case 'MOMO_EWALLET':
        //         paymentUrl = await MomoAdapter.createPaymentUrl(dto.amount, gateway.config);
        //         break;
        //     case 'VNPAY_QR':
        //         paymentUrl = await VNPayAdapter.createPaymentUrl(dto.amount, gateway.config);
        //         break;
        //     default:
        //         throw new BadRequestException('Adapter cho cổng thanh toán này chưa được triển khai.');
        // }
        
        // 3. Tạm thời, chúng ta vẫn giả lập link trả về cho frontend
        return {
            paymentUrl: `https://example-payment-gateway.com/pay?amount=${dto.amount}&orderId=${new Date().getTime()}&gateway=${gateway.gatewayCode}`,
            message: 'Vui lòng hoàn tất thanh toán tại URL được cung cấp.',
        };
    }

    /**
     * === LOGIC MỚI CHO P2P TRANSFER ===
     * Chuyển tiền giữa hai ví của hai tổ chức.
     * Toàn bộ logic được bọc trong một transaction để đảm bảo an toàn.
     */
    async transferFunds(dto: TransferFundsDto, initiatedByUser: User): Promise<{ fromTransaction: Transaction, toTransaction: Transaction }> {
        const { fromOrganizationId, recipientIdentifier, amount, description } = dto;
        this.logger.log(`P2P Transfer initiated by ${initiatedByUser.email}: ${amount} from org ${fromOrganizationId} to ${recipientIdentifier}`);

        return this.dataSource.transaction(async manager => {
            // 1. Lấy ví của người gửi
            const fromWallet = await manager.findOne(Wallet, { where: { organization: { id: fromOrganizationId } } });
            if (!fromWallet) throw new NotFoundException('Không tìm thấy ví của người gửi.');
            if (fromWallet.balance < amount) throw new BadRequestException('Số dư không đủ để thực hiện giao dịch.');

            // 2. Tìm tổ chức người nhận (có thể tìm theo ID hoặc email owner)
            const recipientOrg = await this.organizationsService.findByIdentifier(recipientIdentifier, manager);
            if (!recipientOrg) throw new NotFoundException('Không tìm thấy tổ chức người nhận.');
            if (recipientOrg.id === fromOrganizationId) throw new BadRequestException('Không thể tự chuyển tiền cho chính mình.');
            
            // 3. Lấy ví của người nhận
            const toWallet = await manager.findOne(Wallet, { where: { organization: { id: recipientOrg.id } } });
            if (!toWallet) throw new NotFoundException('Không tìm thấy ví của người nhận.');

            // 4. Ghi nhận giao dịch trừ tiền ở ví gửi
            const fromTransaction = await this.recordTransaction(
                fromWallet, 'p2p_sent', -amount, `Chuyển tiền tới ${recipientOrg.companyName}: ${description}`, initiatedByUser, manager
            );

            // 5. Ghi nhận giao dịch cộng tiền ở ví nhận
            const toTransaction = await this.recordTransaction(
                toWallet, 'p2p_received', amount, `Nhận tiền từ ${fromWallet.organization.companyName}: ${description}`, initiatedByUser, manager
            );

            this.logger.log(`P2P Transfer successful. From Tx: ${fromTransaction.id}, To Tx: ${toTransaction.id}`);
            return { fromTransaction, toTransaction };
        });
    }

    /**
     * Ghi nhận một giao dịch và cập nhật số dư.
     * Phiên bản đã nâng cấp để hỗ trợ transaction lồng nhau và tránh race condition.
     */
    async recordTransaction(
        wallet: Wallet,
        type: TransactionType,
        amount: number,
        description: string,
        initiatedBy: User | null,
        manager?: EntityManager,
    ): Promise<Transaction> {
        const transactionCallback = async (tm: EntityManager) => {
            // Lấy lại thông tin wallet mới nhất bên trong transaction để tránh race condition
            const currentWallet = await tm.findOne(Wallet, { where: { id: wallet.id }, lock: { mode: 'pessimistic_write' } });
            const currentBalance = Number(currentWallet.balance) || 0;
            const transactionAmount = Number(amount) || 0;
            const newBalance = currentBalance + transactionAmount;

            if (newBalance < 0) {
                throw new BadRequestException('Số dư không đủ.');
            }

            await tm.update(Wallet, currentWallet.id, { balance: newBalance });
            
            const newTransaction = tm.create(Transaction, {
                wallet: currentWallet,
                type,
                amount: transactionAmount,
                balanceAfter: newBalance,
                description,
                initiatedBy,
            });
            
            const savedTx = await tm.save(newTransaction);
            this.logger.log(`Transaction recorded: [${savedTx.id}] Wallet: ${wallet.id}, Type: ${type}, Amount: ${amount}, New Balance: ${newBalance}`);
            return savedTx;
        };

        if (manager) {
            return transactionCallback(manager);
        } else {
            return this.dataSource.transaction(transactionCallback);
        }
    }
}