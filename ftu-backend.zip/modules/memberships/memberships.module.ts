// File: ftu-backend/src/modules/memberships/memberships.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MembershipPlan } from './entities/membership-plan.entity';
import { UserMembership } from './entities/user-membership.entity';
import { MembershipsService } from './memberships.service';

@Module({
  imports: [TypeOrmModule.forFeature([MembershipPlan, UserMembership])],
  providers: [MembershipsService],
  exports: [MembershipsService], // Xuất service để các module khác sử dụng
})
export class MembershipsModule {}