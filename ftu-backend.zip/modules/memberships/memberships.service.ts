// File: ftu-backend/src/modules/memberships/memberships.service.ts
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, MoreThan } from 'typeorm';
import { UserMembership } from './entities/user-membership.entity';
import { MembershipPlan } from './entities/membership-plan.entity';
import { Organization } from '../organizations/entities/organization.entity';
import { Subscription } from '../billing/entities/subscription.entity';

@Injectable()
export class MembershipsService {
    constructor(
        @InjectRepository(UserMembership)
        private readonly userMembershipRepository: Repository<UserMembership>,
        @InjectRepository(MembershipPlan)
        private readonly membershipPlanRepository: Repository<MembershipPlan>,
    ) {}

    /**
     * Tạo mới hoặc gia hạn một gói thành viên cho tổ chức.
     * Sẽ được gọi bởi BillingService sau khi thanh toán cho một gói membership thành công.
     * @param organization - Tổ chức đăng ký gói.
     * @param subscription - Gói thuê bao vừa được thanh toán thành công.
     * @returns {Promise<UserMembership>} - Bản ghi thành viên đã được tạo/cập nhật.
     */
    async createOrUpdateUserMembership(organization: Organization, subscription: Subscription): Promise<UserMembership> {
        const plan = subscription.plan; // Plan ở đây chính là MembershipPlan
        const expiresAt = subscription.currentPeriodEnd;

        // Tìm xem tổ chức này đã có bản ghi thành viên chưa
        let userMembership = await this.userMembershipRepository.findOne({
            where: { organization: { id: organization.id } }
        });

        if (userMembership) {
            // Nếu đã có -> Cập nhật (gia hạn)
            userMembership.plan = plan as any; // Cần ép kiểu vì plan từ subscription là Plan chung
            userMembership.subscription = subscription;
            userMembership.expiresAt = expiresAt;
            userMembership.status = 'active';
        } else {
            // Nếu chưa có -> Tạo mới
            userMembership = this.userMembershipRepository.create({
                organization,
                plan: plan as any,
                subscription,
                expiresAt,
                status: 'active',
            });
        }

        return this.userMembershipRepository.save(userMembership);
    }

    /**
     * Lấy thông tin gói thành viên đang hoạt động của một tổ chức.
     * Các service khác sẽ gọi hàm này để kiểm tra quyền lợi.
     * @param organizationId - ID của tổ chức cần kiểm tra.
     * @returns {Promise<UserMembership | null>} - Gói thành viên đang active hoặc null nếu không có.
     */
    async getActiveMembershipForOrg(organizationId: string): Promise<UserMembership | null> {
        return this.userMembershipRepository.findOne({
            where: {
                organization: { id: organizationId },
                status: 'active',
                expiresAt: MoreThan(new Date()), // Đảm bảo gói vẫn còn hạn
            },
            relations: ['plan'], // Lấy luôn thông tin plan để biết benefits
        });
    }

    // Các hàm khác có thể thêm sau: hủy gói, lấy lịch sử gói...
}