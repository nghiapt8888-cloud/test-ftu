// File: ftu-backend/src/modules/memberships/entities/membership-plan.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

/**
 * Enum để xác định loại gói Membership.
 * - USER: Gói dành cho khách hàng cuối (CEOs, managers).
 * - PARTNER: Gói dành cho các đối tác phát triển giải pháp.
 */
export type MembershipPlanType = 'USER' | 'PARTNER';

@Entity('membership_plans')
export class MembershipPlan {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Column()
    name: string; // Ví dụ: "Gói Bạc", "Gói Vàng", "Partner Pro"

    @Column({
        type: 'enum',
        enum: ['USER', 'PARTNER'],
        default: 'USER',
    })
    type: MembershipPlanType;

    @Column({ type: 'decimal', precision: 12, scale: 2, name: 'price_monthly', default: 0 })
    priceMonthly: number;

    @Column({ type: 'decimal', precision: 12, scale: 2, name: 'price_yearly', default: 0 })
    priceYearly: number;

    /**
     * Lưu trữ các quyền lợi của gói dưới dạng JSON.
     * Cấu trúc linh hoạt, không cần thay đổi CSDL khi thêm quyền lợi mới.
     * Ví dụ cho USER: { "solutionDiscountRate": 0.1, "p2pTransferFee": 0.005 }
     * Ví dụ cho PARTNER: { "commissionBoost": 0.05, "featuredSolutionSlots": 1 }
     */
    @Column({ type: 'jsonb', default: {} })
    benefits: any;
    
    @Column({ default: true })
    isActive: boolean;

    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;

    @UpdateDateColumn({ name: 'updated_at' })
    updatedAt: Date;
}