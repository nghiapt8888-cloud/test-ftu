// File: ftu-backend/src/modules/memberships/entities/user-membership.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Organization } from '../../organizations/entities/organization.entity';
import { MembershipPlan } from './membership-plan.entity';
import { Subscription } from '../../billing/entities/subscription.entity';

export type UserMembershipStatus = 'active' | 'expired' | 'canceled';

@Entity('user_memberships')
export class UserMembership {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    // Gói thành viên này thuộc về tổ chức nào
    @ManyToOne(() => Organization, { nullable: false })
    @JoinColumn({ name: 'organization_id' })
    organization: Organization;

    // Gói thành viên đang đăng ký là gói nào
    @ManyToOne(() => MembershipPlan, { nullable: false })
    @JoinColumn({ name: 'plan_id' })
    plan: MembershipPlan;
    
    // Gói thành viên này được kích hoạt/gia hạn bởi gói thuê bao nào
    @ManyToOne(() => Subscription, { nullable: false })
    @JoinColumn({ name: 'subscription_id' })
    subscription: Subscription;

    @Column({
        type: 'enum',
        enum: ['active', 'expired', 'canceled'],
        default: 'active',
    })
    status: UserMembershipStatus;

    @Column({ name: 'expires_at', type: 'timestamp' })
    expiresAt: Date; // Ngày hết hạn của gói thành viên

    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;

    @UpdateDateColumn({ name: 'updated_at' })
    updatedAt: Date;
}