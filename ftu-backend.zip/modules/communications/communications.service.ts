// File: ftu-backend/src/modules/communications/communications.service.ts
import { Injectable, InternalServerErrorException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CommProvider } from '../../platform_admin/communications_config/entities/comm-provider.entity';
import { SmtpAdapter } from './adapters/smtp.adapter';

@Injectable()
export class CommunicationsService {
    private readonly logger = new Logger(CommunicationsService.name);

    constructor(
        @InjectRepository(CommProvider)
        private readonly commProviderRepository: Repository<CommProvider>,
    ) {}

    /**
     * Gửi một thông điệp (ví dụ: email) thông qua nhà cung cấp đang hoạt động.
     * @param to - Địa chỉ người nhận.
     * @param subject - Tiêu đề của thông điệp.
     * @param htmlContent - Nội dung HTML của thông điệp.
     * @param textContent - (Tùy chọn) Nội dung dạng văn bản thuần.
     */
    async send(to: string, subject: string, htmlContent: string, textContent?: string): Promise<boolean> {
        // 1. Tìm nhà cung cấp dịch vụ giao tiếp đang được kích hoạt trong hệ thống.
        const activeProvider = await this.commProviderRepository.findOne({
            where: { isActive: true },
        });

        if (!activeProvider) {
            // Cập nhật thông điệp lỗi sang tiếng Anh
            this.logger.error('No active communication provider (CommProvider) found.'); 
            throw new InternalServerErrorException('Hệ thống giao tiếp chưa được cấu hình.');
        }

        this.logger.log(`Đang sử dụng nhà cung cấp '${activeProvider.providerName}' để gửi thông điệp.`);

        // 2. Dựa vào mã nhà cung cấp, chọn Adapter tương ứng để xử lý việc gửi.
        try {
            switch (activeProvider.providerCode) {
                case 'SMTP_DEFAULT': // Giả định chúng ta sẽ tạo một cấu hình SMTP mặc định
                    await SmtpAdapter.send(
                        activeProvider.config,
                        to,
                        subject,
                        htmlContent,
                        textContent
                    );
                    break;
                // --- Có thể thêm các case khác trong tương lai ---
                // case 'SENDGRID_API':
                //     await SendGridAdapter.send(...)
                //     break;
                default:
                    this.logger.error(`Adapter cho nhà cung cấp '${activeProvider.providerCode}' chưa được triển khai.`);
                    throw new InternalServerErrorException('Nhà cung cấp dịch vụ không được hỗ trợ.');
            }
            this.logger.log(`Thông điệp đã được gửi thành công tới: ${to}`);
            return true;
        } catch (error) {
            this.logger.error(`Gửi thông điệp tới '${to}' thất bại. Lỗi: ${error.message}`, error.stack);
            // Không re-throw lỗi để tránh làm sập các tiến trình khác (ví dụ: đăng ký thành công nhưng gửi mail lỗi)
            return false;
        }
    }
}