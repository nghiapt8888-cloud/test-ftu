// File: ftu-backend/src/modules/communications/communications.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CommunicationsService } from './communications.service';
import { CommProvider } from '../../platform_admin/communications_config/entities/comm-provider.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([CommProvider]),
  ],
  providers: [CommunicationsService],
  exports: [CommunicationsService],
})
export class CommunicationsModule {}