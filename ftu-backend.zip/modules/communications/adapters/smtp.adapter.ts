// File: ftu-backend/src/modules/communications/adapters/smtp.adapter.ts
import * as nodemailer from 'nodemailer';

// Định nghĩa cấu trúc cho đối tượng config mà adapter này mong đợi
interface SmtpConfig {
    host: string;
    port: number;
    secure: boolean; // true for 465, false for other ports
    auth: {
        user: string; // Tên đăng nhập SMTP
        pass: string; // Mật khẩu SMTP
    };
    fromName: string; // Tên người gửi, ví dụ: "FTU Platform"
    fromEmail: string; // Email người gửi
}

export class SmtpAdapter {
    /**
     * Gửi email sử dụng một cấu hình SMTP cụ thể.
     * @param config - Cấu hình SMTP lấy từ CommProvider trong CSDL.
     * @param to - Địa chỉ email người nhận.
     * @param subject - Tiêu đề email.
     * @param htmlContent - Nội dung email dạng HTML.
     * @param textContent - (Tùy chọn) Nội dung email dạng văn bản thuần.
     */
    static async send(
        config: SmtpConfig,
        to: string,
        subject: string,
        htmlContent: string,
        textContent?: string,
    ): Promise<void> {
        // 1. Tạo một đối tượng transporter bằng cách sử dụng cấu hình SMTP
        const transporter = nodemailer.createTransport({
            host: config.host,
            port: config.port,
            secure: config.secure,
            auth: {
                user: config.auth.user,
                pass: config.auth.pass,
            },
        });

        // 2. Định nghĩa các tùy chọn cho email
        const mailOptions = {
            from: `"${config.fromName}" <${config.fromEmail}>`, // "FTU Platform" <no-reply@ftu.com>
            to: to,
            subject: subject,
            text: textContent, // Nội dung dạng text cho các email client không hỗ trợ HTML
            html: htmlContent, // Nội dung dạng HTML
        };

        // 3. Gửi email và xử lý kết quả
        try {
            const info = await transporter.sendMail(mailOptions);
            console.log('Message sent: %s', info.messageId);
        } catch (error) {
            console.error('Error sending email via SMTP:', error);
            // Re-throw lỗi để service có thể bắt và ghi log
            throw new Error(`SMTP sending failed: ${error.message}`);
        }
    }
}