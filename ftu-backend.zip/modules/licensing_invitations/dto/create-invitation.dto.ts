// File: ftu-backend/src/modules/licensing_invitations/dto/create-invitation.dto.ts
import { IsEmail, IsNotEmpty, IsOptional, IsString, IsUUID } from 'class-validator';

export class CreateGiftInvitationDto {
    @IsNotEmpty({ message: 'Vui lòng chọn một gói quà.' })
    @IsUUID('4', { message: 'ID của Gói cước không hợp lệ.' })
    planId: string;

    @IsNotEmpty({ message: 'Email người nhận không được để trống.' })
    @IsEmail({}, { message: 'Email người nhận không hợp lệ.' })
    recipientEmail: string;

    @IsOptional()
    @IsString()
    title?: string;

    @IsOptional()
    @IsString()
    message?: string;
}