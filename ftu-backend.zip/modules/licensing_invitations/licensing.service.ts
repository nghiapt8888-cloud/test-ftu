// File: ftu-backend/src/modules/licensing_invitations/licensing.service.ts
import { Injectable, NotFoundException, BadRequestException, ForbiddenException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { addDays } from 'date-fns';
import { randomBytes } from 'crypto';

import { License } from './entities/license.entity';
import { Invitation } from './entities/invitation.entity';
import { CreateGiftInvitationDto } from './dto/create-invitation.dto';

import { WalletsService } from '../wallets/wallets.service';
import { MarketplaceService } from '../marketplace/marketplace.service';
import { OrganizationsService } from '../organizations/organizations.service';
import { User } from '../accounts/entities/user.entity';
import { Organization } from '../organizations/entities/organization.entity';
import { CommunicationsService } from '../communications/communications.service';
import { NotificationsService } from '../notifications/notifications.service';

@Injectable()
export class LicensingService {
    private readonly logger = new Logger(LicensingService.name);

    constructor(
        private readonly dataSource: DataSource,
        @InjectRepository(License) private readonly licenseRepository: Repository<License>,
        @InjectRepository(Invitation) private readonly invitationRepository: Repository<Invitation>,
        private readonly walletsService: WalletsService,
        private readonly marketplaceService: MarketplaceService,
        private readonly organizationsService: OrganizationsService,
        private readonly communicationsService: CommunicationsService,
        private readonly notificationsService: NotificationsService,
    ) {}

    /**
     * Tạo một lời mời tặng quà (Gifting).
     */
    async createGiftInvitation(dto: CreateGiftInvitationDto, senderUser: User, senderOrganization: Organization): Promise<Invitation> {
        const { planId, recipientEmail } = dto;
        
        this.logger.log(`User ${senderUser.email} from org ${senderOrganization.id} is gifting plan ${planId} to ${recipientEmail}`);

        const plan = await this.marketplaceService.findPlanById(planId);
        if (!plan) {
            throw new NotFoundException(`Gói cước với ID ${planId} không tồn tại.`);
        }

        const senderWallet = await this.walletsService.getWalletByOrgId(senderOrganization.id);
        if (senderWallet.balance < plan.price) {
            throw new BadRequestException('Số dư trong ví không đủ để thực hiện giao dịch này.');
        }
        
        return this.dataSource.transaction(async manager => {
            const description = `Mua và tặng gói '${plan.name}' cho ${recipientEmail}`;
            await this.walletsService.recordTransaction(
                senderWallet, 'purchase', -plan.price, description, senderUser, manager
            );

            const newLicense = manager.create(License, { status: 'pending_acceptance' });
            await manager.save(newLicense);

            const token = randomBytes(32).toString('hex');
            const expiresAt = addDays(new Date(), 7);

            const newInvitation = manager.create(Invitation, {
                senderOrganization, sentByUser: senderUser, recipientEmail,
                plan, token, expiresAt, license: newLicense, status: 'pending',
            });
            
            const savedInvitation = await manager.save(newInvitation);
            this.logger.log(`Invitation ${savedInvitation.id} created successfully.`);

            // --- KÍCH HOẠT GỬI EMAIL ---
            const invitationLink = `${process.env.FRONTEND_URL}/accept-invitation/${token}`;
            const emailHtmlContent = `
                <h1>Bạn có một món quà!</h1>
                <p><b>${senderOrganization.companyName}</b> đã gửi tặng bạn gói cước <b>${plan.solution.name} - ${plan.name}</b>.</p>
                ${dto.message ? `<p><i>Lời nhắn: ${dto.message}</i></p>` : ''}
                <p>Vui lòng nhấn vào nút bên dưới để chấp nhận món quà này. Lời mời có hiệu lực trong 7 ngày.</p>
                <a href="${invitationLink}" style="padding: 10px 15px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">
                    Chấp nhận ngay
                </a>
            `;

            await this.communicationsService.send(
                recipientEmail,
                dto.title || `Bạn có một món quà từ ${senderOrganization.companyName}`,
                emailHtmlContent
            );

            return savedInvitation;
        });
    }

    /**
     * Lấy thông tin chi tiết của một lời mời dựa vào token.
     */
    async getInvitationDetailsByToken(token: string): Promise<Invitation> {
        const invitation = await this.invitationRepository.findOne({
            where: { token },
            relations: ['plan', 'plan.solution', 'senderOrganization'],
        });

        if (!invitation || invitation.status !== 'pending' || new Date() > invitation.expiresAt) {
            throw new NotFoundException('Lời mời không hợp lệ, đã được chấp nhận hoặc đã hết hạn.');
        }
        return invitation;
    }

    /**
     * Xử lý khi người dùng chấp nhận lời mời tặng quà.
     */
    async acceptInvitation(token: string, recipientUser: User): Promise<License> {
        this.logger.log(`User ${recipientUser.email} is attempting to accept invitation with token ${token}`);
        return this.dataSource.transaction(async manager => {
            const invitation = await manager.findOne(Invitation, {
                where: { token },
                relations: ['license', 'senderUser', 'plan'],
                lock: { mode: 'pessimistic_write' },
            });

            if (!invitation || invitation.status !== 'pending' || new Date() > invitation.expiresAt) {
                throw new BadRequestException('Lời mời không hợp lệ, đã được chấp nhận hoặc đã hết hạn.');
            }

            const recipientOrganization = await this.organizationsService.findPrimaryOrganizationByUserId(recipientUser.id, manager);
            if (!recipientOrganization) {
                 throw new BadRequestException('Không tìm thấy tổ chức hợp lệ cho người nhận.');
            }

            const license = invitation.license;
            license.organization = recipientOrganization;
            license.status = 'active';
            await manager.save(license);

            invitation.status = 'accepted';
            invitation.recipientUser = recipientUser; // Cập nhật người đã nhận
            await manager.save(invitation);
            
            // --- KÍCH HOẠT GỬI THÔNG BÁO ---
            await this.notificationsService.create(
                invitation.senderUser,
                'Quà tặng đã được chấp nhận!',
                `${recipientUser.firstName} ${recipientUser.lastName} đã chấp nhận gói ${invitation.plan.name} bạn tặng.`,
                '/dashboard/gifting' // Điều hướng đến trang quản lý quà tặng
            );

            this.logger.log(`User ${recipientUser.email} successfully accepted invitation. License ${license.id} is now active for org ${recipientOrganization.id}.`);
            return license;
        });
    }
}