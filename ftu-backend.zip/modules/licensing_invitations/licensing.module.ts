// File: ftu-backend/src/modules/licensing_invitations/licensing.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { License } from './entities/license.entity';
import { Invitation } from './entities/invitation.entity';
import { LicensingController } from './licensing.controller';
import { LicensingService } from './licensing.service';

import { AuthModule } from '../../core/auth/auth.module';
import { WalletsModule } from '../wallets/wallets.module';
import { MarketplaceModule } from '../marketplace/marketplace.module';
import { OrganizationsModule } from '../organizations/organizations.module';
// import { CommunicationsModule } from '../communications/communications.module'; // Sẽ uncomment khi module này hoàn chỉnh

@Module({
  imports: [
    TypeOrmModule.forFeature([License, Invitation]),
    AuthModule,
    WalletsModule,
    MarketplaceModule,
    OrganizationsModule,
    // CommunicationsModule,
  ],
  controllers: [LicensingController],
  providers: [LicensingService],
})
export class LicensingInvitationsModule {}