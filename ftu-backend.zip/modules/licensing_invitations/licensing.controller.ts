// File: ftu-backend/src/modules/licensing_invitations/licensing.controller.ts
import { Controller, Post, Body, UseGuards, Req, Param, Get } from '@nestjs/common';
import { JwtAuthGuard } from '../../core/auth/guards/jwt-auth.guard';
import { CreateGiftInvitationDto } from './dto/create-invitation.dto';
import { LicensingService } from './licensing.service';
import { User } from '../accounts/entities/user.entity';
import { IRequestWithOrganization } from '../../core/auth/guards/organization-member.guard';

@Controller('licensing')
export class LicensingController {
    constructor(private readonly licensingService: LicensingService) {}

    @UseGuards(JwtAuthGuard) // TODO: Sẽ thêm OrganizationMemberGuard sau
    @Post('gift')
    createGiftInvitation(
        @Body() dto: CreateGiftInvitationDto,
        @Req() req: IRequestWithOrganization,
    ) {
        // Guard sẽ đảm bảo req.user và req.organization tồn tại
        return this.licensingService.createGiftInvitation(dto, req.user, req.organization);
    }

    /**
     * Endpoint công khai để lấy thông tin lời mời.
     */
    @Get('invitations/:token')
    getInvitationDetails(@Param('token') token: string) {
        return this.licensingService.getInvitationDetailsByToken(token);
    }

    /**
     * Endpoint được bảo vệ để người dùng đã đăng nhập chấp nhận lời mời.
     */
    @UseGuards(JwtAuthGuard)
    @Post('invitations/:token/accept')
    acceptInvitation(
        @Param('token') token: string,
        @Req() req: { user: User }
    ) {
        return this.licensingService.acceptInvitation(token, req.user);
    }
}