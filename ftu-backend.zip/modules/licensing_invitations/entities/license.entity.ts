// File: ftu-backend/src/modules/licensing_invitations/entities/license.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn, OneToOne } from 'typeorm';
import { Organization } from '../../organizations/entities/organization.entity';
import { Subscription } from '../../billing/entities/subscription.entity';
import { Invitation } from './invitation.entity';

@Entity('licensing_licenses')
export class License {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    // Tổ chức sở hữu giấy phép này
    @ManyToOne(() => Organization)
    @JoinColumn({ name: 'organization_id' })
    organization: Organization;

    // Giấy phép này được tạo ra từ gói thuê bao nào
    @OneToOne(() => Subscription)
    @JoinColumn({ name: 'subscription_id' })
    subscription: Subscription;

    // Trạng thái của giấy phép
    @Column({
        type: 'enum',
        enum: ['pending_acceptance', 'active', 'revoked', 'expired'],
        default: 'pending_acceptance',
    })
    status: 'pending_acceptance' | 'active' | 'revoked' | 'expired';
    
    // Giấy phép này được kích hoạt thông qua lời mời nào (quan trọng cho luồng gifting)
    @OneToOne(() => Invitation, invitation => invitation.license)
    invitation: Invitation;

    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;
}