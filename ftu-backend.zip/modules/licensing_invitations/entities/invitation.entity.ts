// File: ftu-backend/src/modules/licensing_invitations/entities/invitation.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn, OneToOne } from 'typeorm';
import { Organization } from '../../organizations/entities/organization.entity';
import { User } from '../../accounts/entities/user.entity';
import { Plan } from '../../marketplace/entities/plan.entity';
import { License } from './license.entity';

@Entity('licensing_invitations')
export class Invitation {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    // Tổ chức đã gửi lời mời này
    @ManyToOne(() => Organization)
    @JoinColumn({ name: 'sender_organization_id' })
    senderOrganization: Organization;

    // Người dùng đã thực hiện hành động gửi
    @ManyToOne(() => User)
    @JoinColumn({ name: 'sent_by_user_id' })
    sentByUser: User;

    @Column({ name: 'recipient_email' })
    recipientEmail: string;

    // Gói cước được tặng
    @ManyToOne(() => Plan)
    @JoinColumn({ name: 'plan_id' })
    plan: Plan;

    // Mã token duy nhất để kích hoạt
    @Column({ unique: true })
    token: string;

    @Column({
        type: 'enum',
        enum: ['pending', 'accepted', 'expired'],
        default: 'pending',
    })
    status: 'pending' | 'accepted' | 'expired';
    
    // Lời mời này sẽ kích hoạt giấy phép nào
    @OneToOne(() => License, license => license.invitation)
    @JoinColumn({ name: 'license_id' })
    license: License;

    @Column({ name: 'expires_at', type: 'timestamp' })
    expiresAt: Date; // Lời mời có thời hạn

    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;
}