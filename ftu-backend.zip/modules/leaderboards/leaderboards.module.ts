// File: ftu-backend/src/modules/leaderboards/leaderboards.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LeaderboardsService } from './leaderboards.service';
import { LeaderboardsController } from './leaderboards.controller';
import { Follow } from './entities/follow.entity';
import { Subscription } from '../billing/entities/subscription.entity';
import { Commission } from '../affiliates/entities/commission.entity';
import { AuthModule } from '../../core/auth/auth.module';
import { NotificationsModule } from '../notifications/notifications.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Follow,
      Subscription,
      Commission,
    ]),
    AuthModule,
    NotificationsModule,
  ],
  controllers: [LeaderboardsController],
  providers: [LeaderboardsService],
})
export class LeaderboardsModule {}