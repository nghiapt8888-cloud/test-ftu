// File: ftu-backend/src/modules/leaderboards/leaderboards.service.ts
import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, MoreThanOrEqual, LessThanOrEqual, Between } from 'typeorm';
import { startOfWeek, endOfWeek, startOfMonth, endOfMonth, startOfYear, endOfYear, subDays } from 'date-fns';

import { Follow } from './entities/follow.entity';
import { Solution } from '../marketplace/entities/solution.entity';
import { Subscription } from '../billing/entities/subscription.entity';
import { Commission } from '../affiliates/entities/commission.entity';
import { User } from '../accounts/entities/user.entity';
import { NotificationsService } from '../notifications/notifications.service';

export type LeaderboardTimeFilter = 'weekly' | 'monthly' | 'yearly' | 'all_time';

@Injectable()
export class LeaderboardsService {
    constructor(
        @InjectRepository(Follow)
        private readonly followRepository: Repository<Follow>,
        @InjectRepository(Subscription)
        private readonly subscriptionRepository: Repository<Subscription>,
        @InjectRepository(Commission)
        private readonly commissionRepository: Repository<Commission>,
        private readonly notificationsService: NotificationsService,
    ) {}

    private getDateRange(filter: LeaderboardTimeFilter): { startDate: Date; endDate: Date } {
        const now = new Date();
        switch (filter) {
            case 'weekly':
                return { startDate: startOfWeek(now), endDate: endOfWeek(now) };
            case 'monthly':
                return { startDate: startOfMonth(now), endDate: endOfMonth(now) };
            case 'yearly':
                return { startDate: startOfYear(now), endDate: endOfYear(now) };
            default: // all_time
                return { startDate: new Date(0), endDate: now }; // From epoch to now
        }
    }

    /**
     * Lấy bảng xếp hạng các giải pháp bán chạy nhất.
     */
    async getSolutionLeaderboard(timeFilter: LeaderboardTimeFilter, categoryId?: string, limit = 10) {
        const { startDate, endDate } = this.getDateRange(timeFilter);

        const query = this.subscriptionRepository.createQueryBuilder('sub')
            .select('solution.id', 'solutionId')
            .addSelect('solution.name', 'solutionName')
            .addSelect('solution.logoUrl', 'solutionLogoUrl')
            .addSelect('COUNT(sub.id)', 'salesCount')
            .innerJoin('sub.plan', 'plan')
            .innerJoin('plan.solution', 'solution')
            .where('sub.createdAt BETWEEN :startDate AND :endDate', { startDate, endDate })
            .andWhere('solution.isActive = :isActive', { isActive: true })
            .groupBy('solution.id')
            .orderBy('"salesCount"', 'DESC')
            .limit(limit);

        if (categoryId) {
            query.andWhere('solution.categoryId = :categoryId', { categoryId });
        }

        return query.getRawMany();
    }

    /**
     * Lấy bảng xếp hạng các cộng tác viên (affiliates) hiệu quả nhất.
     */
    async getAffiliateLeaderboard(timeFilter: LeaderboardTimeFilter, limit = 10) {
        const { startDate, endDate } = this.getDateRange(timeFilter);

        return this.commissionRepository.createQueryBuilder('comm')
            .select('affiliate.id', 'affiliateId')
            .addSelect('user.firstName', 'userFirstName')
            .addSelect('user.lastName', 'userLastName')
            .addSelect('user.avatarUrl', 'userAvatarUrl')
            .addSelect('SUM(comm.amount)', 'totalCommission')
            .innerJoin('comm.affiliate', 'affiliate')
            .innerJoin('affiliate.user', 'user')
            .where('comm.createdAt BETWEEN :startDate AND :endDate', { startDate, endDate })
            .andWhere("comm.status != 'rejected'") // Chỉ tính hoa hồng không bị từ chối
            .groupBy('affiliate.id, user.id')
            .orderBy('"totalCommission"', 'DESC')
            .limit(limit)
            .getRawMany();
    }

    /**
     * Cho phép người dùng theo dõi một giải pháp.
     */
    async followSolution(user: User, solutionId: string): Promise<Follow> {
        const solution = new Solution();
        solution.id = solutionId;

        const existingFollow = await this.followRepository.findOne({ where: { user: { id: user.id }, solution: { id: solutionId } } });
        if (existingFollow) {
            throw new ConflictException('Bạn đã theo dõi giải pháp này rồi.');
        }

        const newFollow = this.followRepository.create({ user, solution });
        
        // TODO: Lấy thông tin partner của solution để gửi thông báo
        // const partner = solution.partner;
        // if (partner) {
        //     await this.notificationsService.create(
        //         partner.user, 
        //         'Có người theo dõi mới', 
        //         `${user.firstName} ${user.lastName} vừa theo dõi giải pháp ${solution.name} của bạn.`,
        //         `/partner/solutions/${solutionId}/followers`
        //     );
        // }

        return this.followRepository.save(newFollow);
    }

    /**
     * Cho phép người dùng bỏ theo dõi một giải pháp.
     */
    async unfollowSolution(user: User, solutionId: string): Promise<void> {
        const result = await this.followRepository.delete({
            user: { id: user.id },
            solution: { id: solutionId },
        });

        if (result.affected === 0) {
            throw new NotFoundException('Bạn chưa theo dõi giải pháp này hoặc giải pháp không tồn tại.');
        }
    }
}