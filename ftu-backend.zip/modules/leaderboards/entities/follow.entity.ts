// File: ftu-backend/src/modules/leaderboards/entities/follow.entity.ts
import { Entity, PrimaryGeneratedColumn, ManyToOne, JoinColumn, CreateDateColumn, Unique } from 'typeorm';
import { User } from '../../accounts/entities/user.entity';
import { Solution } from '../../marketplace/entities/solution.entity';

@Entity('leaderboard_follows')
@Unique(['user', 'solution']) // Đảm bảo một người dùng chỉ có thể theo dõi một giải pháp một lần
export class Follow {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    // Người dùng thực hiện hành động theo dõi
    @ManyToOne(() => User, { onDelete: 'CASCADE' })
    @JoinColumn({ name: 'user_id' })
    user: User;

    // Giải pháp được theo dõi
    @ManyToOne(() => Solution, { onDelete: 'CASCADE' })
    @JoinColumn({ name: 'solution_id' })
    solution: Solution;

    // Có thể mở rộng để theo dõi Partner trong tương lai
    // @ManyToOne(() => Partner, { onDelete: 'CASCADE' })
    // @JoinColumn({ name: 'partner_id' })
    // partner: Partner;

    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;
}