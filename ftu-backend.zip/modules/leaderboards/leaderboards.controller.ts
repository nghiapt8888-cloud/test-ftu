// File: ftu-backend/src/modules/leaderboards/leaderboards.controller.ts
import { Controller, Get, Post, Delete, Param, Query, UseGuards, Req, ParseUUIDPipe, ValidationPipe } from '@nestjs/common';
import { LeaderboardsService, LeaderboardTimeFilter } from './leaderboards.service';
import { JwtAuthGuard } from '../../core/auth/guards/jwt-auth.guard';
import { User } from '../accounts/entities/user.entity';

@Controller('leaderboards')
export class LeaderboardsController {
    constructor(private readonly leaderboardsService: LeaderboardsService) {}

    // --- Public Endpoints ---

    @Get('solutions')
    getSolutionLeaderboard(
        @Query('timeFilter') timeFilter: LeaderboardTimeFilter = 'monthly',
        @Query('categoryId') categoryId?: string,
    ) {
        return this.leaderboardsService.getSolutionLeaderboard(timeFilter, categoryId);
    }

    @Get('affiliates')
    getAffiliateLeaderboard(
        @Query('timeFilter') timeFilter: LeaderboardTimeFilter = 'monthly',
    ) {
        return this.leaderboardsService.getAffiliateLeaderboard(timeFilter);
    }


    // --- Authenticated Endpoints for Interaction ---

    @UseGuards(JwtAuthGuard)
    @Post('solutions/:id/follow')
    followSolution(
        @Req() req: { user: User },
        @Param('id', ParseUUIDPipe) solutionId: string,
    ) {
        return this.leaderboardsService.followSolution(req.user, solutionId);
    }

    @UseGuards(JwtAuthGuard)
    @Delete('solutions/:id/follow')
    unfollowSolution(
        @Req() req: { user: User },
        @Param('id', ParseUUIDPipe) solutionId: string,
    ) {
        return this.leaderboardsService.unfollowSolution(req.user, solutionId);
    }
}