// File: ftu-backend/src/modules/organizations/dto/update-member-role.dto.ts
import { IsIn, IsNotEmpty, IsString } from 'class-validator';

export class UpdateMemberRoleDto {
    @IsNotEmpty({ message: 'Vai trò không được để trống.' })
    @IsString()
    @IsIn(['admin', 'member'], { message: 'Vai trò phải là "admin" hoặc "member".' })
    role: 'admin' | 'member';
}