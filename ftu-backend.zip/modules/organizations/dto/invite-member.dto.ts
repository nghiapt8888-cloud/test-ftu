// File: ftu-backend/src/modules/organizations/dto/invite-member.dto.ts
import { IsEmail, IsIn, IsNotEmpty, IsString } from 'class-validator';

export class InviteMemberDto {
    @IsNotEmpty({ message: 'Email không được để trống.' })
    @IsEmail({}, { message: 'Email không hợp lệ.' })
    email: string;

    @IsNotEmpty({ message: 'Vai trò không được để trống.' })
    @IsString()
    @IsIn(['admin', 'member'], { message: 'Vai trò phải là "admin" hoặc "member".' })
    role: 'admin' | 'member';
}