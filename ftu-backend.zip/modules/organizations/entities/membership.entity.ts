// File: ftu-backend/src/modules/organizations/entities/membership.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, Unique } from 'typeorm';

// Export type để sử dụng trong Decorator và Guard
export type MembershipRole = 'owner' | 'admin' | 'member';

@Entity('memberships')
@Unique(['userId', 'organizationId'])
export class Membership {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ name: 'user_id' })
    userId: number;

    @Column({ name: 'organization_id', type: 'uuid' })
    organizationId: string;

    @Column({
        type: 'enum',
        enum: ['owner', 'admin', 'member'],
        default: 'member',
    })
    role: MembershipRole;
}