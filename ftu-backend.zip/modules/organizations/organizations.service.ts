// File: ftu-backend/src/modules/organizations/organizations.service.ts
import { Injectable, NotFoundException, ConflictException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, EntityManager } from 'typeorm';
import { Organization } from './entities/organization.entity';
import { Membership } from './entities/membership.entity';
import { User } from '../accounts/entities/user.entity';
import { AccountsService } from '../accounts/accounts.service'; // Import AccountsService

@Injectable()
export class OrganizationsService {
    constructor(
        @InjectRepository(Organization)
        private readonly organizationRepository: Repository<Organization>,
        @InjectRepository(Membership)
        private readonly membershipRepository: Repository<Membership>,
        private readonly accountsService: AccountsService, // Inject AccountsService
    ) {}

    async create(name: string, owner: User): Promise<Organization> {
        const newOrganization = this.organizationRepository.create({
            companyName: name,
            owner: owner,
        });
        return this.organizationRepository.save(newOrganization);
    }

    async createMembership(userId: number, organizationId: string, role: 'owner' | 'admin' | 'member'): Promise<Membership> {
        const newMembership = this.membershipRepository.create({
            userId,
            organizationId,
            role,
        });
        return this.membershipRepository.save(newMembership);
    }

    async findOrganizationsByUserId(userId: number): Promise<Organization[]> {
        const memberships = await this.membershipRepository.find({ where: { userId } });
        const organizationIds = memberships.map(m => m.organizationId);

        if (organizationIds.length === 0) {
            return [];
        }

        return this.organizationRepository.createQueryBuilder('org')
            .where('org.id IN (:...ids)', { ids: organizationIds })
            .getMany();
    }
    
    /**
     * === HÀM HỖ TRỢ GUARD ===
     * Kiểm tra xem một user có phải là thành viên của một tổ chức không.
     * @param organizationId - ID của tổ chức.
     * @param userId - ID của người dùng.
     * @returns {Promise<Membership | null>} - Trả về membership nếu là thành viên, ngược lại null.
     */
    async findMembership(organizationId: string, userId: number): Promise<Membership | null> {
        return this.membershipRepository.findOne({
            where: { organizationId, userId },
        });
    }

    /**
     * === HÀM MỚI ===
     * Lấy danh sách thành viên của một tổ chức.
     */
    async getMembers(organizationId: string): Promise<any[]> {
        // Cần join với bảng User để lấy thông tin chi tiết
        return this.membershipRepository.createQueryBuilder('membership')
            .innerJoinAndSelect('membership.user', 'user')
            .where('membership.organizationId = :organizationId', { organizationId })
            .select(['membership.role', 'user.id', 'user.email', 'user.firstName', 'user.lastName'])
            .getRawMany();
    }

    /**
     * === HÀM MỚI ===
     * Mời một thành viên mới vào tổ chức.
     */
    async inviteMember(organizationId: string, inviteeEmail: string, role: 'admin' | 'member'): Promise<Membership> {
        const invitee = await this.accountsService.findByEmail(inviteeEmail);
        if (!invitee) {
            throw new NotFoundException(`Người dùng với email ${inviteeEmail} không tồn tại.`);
        }

        const existingMembership = await this.findMembership(organizationId, invitee.id);
        if (existingMembership) {
            throw new ConflictException(`Người dùng ${inviteeEmail} đã là thành viên của tổ chức này.`);
        }

        return this.createMembership(invitee.id, organizationId, role);
    }
    
    /**
     * === HÀM MỚI ===
     * Cập nhật vai trò của một thành viên.
     */
    async updateMemberRole(organizationId: string, userId: number, newRole: 'admin' | 'member'): Promise<Membership> {
        const membership = await this.findMembership(organizationId, userId);
        if (!membership) {
            throw new NotFoundException('Không tìm thấy thành viên trong tổ chức.');
        }
        if (membership.role === 'owner') {
            throw new ForbiddenException('Không thể thay đổi vai trò của chủ sở hữu.');
        }
        membership.role = newRole;
        return this.membershipRepository.save(membership);
    }
    
    /**
     * === HÀM MỚI ===
     * Xóa một thành viên khỏi tổ chức.
     */
    async removeMember(organizationId: string, userId: number): Promise<void> {
        const membership = await this.findMembership(organizationId, userId);
        if (!membership) {
            throw new NotFoundException('Không tìm thấy thành viên trong tổ chức.');
        }
        if (membership.role === 'owner') {
            throw new ForbiddenException('Không thể xóa chủ sở hữu khỏi tổ chức.');
        }
        await this.membershipRepository.remove(membership);
    }


    /**
     * Tìm một tổ chức dựa trên UUID hoặc email của người sở hữu.
     * Hữu ích cho các tính năng như P2P Transfer.
     * @param identifier - Chuỗi UUID hoặc email.
     * @param manager - Optional: EntityManager để thực hiện trong một transaction.
     */
    async findByIdentifier(identifier: string, manager?: EntityManager): Promise<Organization | null> {
        const repository = manager ? manager.getRepository(Organization) : this.organizationRepository;

        // Thử tìm theo ID trước
        let organization = await repository.findOneBy({ id: identifier });
        if (organization) {
            return organization;
        }

        // Nếu không thấy, thử tìm theo email của owner
        organization = await repository.createQueryBuilder('org')
            .innerJoin('org.owner', 'owner')
            .where('owner.email = :email', { email: identifier })
            .getOne();
            
        return organization;
    }
}