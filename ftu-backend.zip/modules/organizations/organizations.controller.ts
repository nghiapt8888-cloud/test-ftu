// File: ftu-backend/src/modules/organizations/organizations.controller.ts
import { 
    Controller, 
    Get, 
    Post, 
    Patch, 
    Delete,
    Param, 
    Body, 
    UseGuards,
    Req,
    ParseUUIDPipe,
    ParseIntPipe,
    HttpCode,
    HttpStatus,
} from '@nestjs/common';
import { JwtAuthGuard } from '../../core/auth/guards/jwt-auth.guard';
import { OrganizationsService } from './organizations.service';
import { InviteMemberDto } from './dto/invite-member.dto';
import { UpdateMemberRoleDto } from './dto/update-member-role.dto';
import { User } from '../accounts/entities/user.entity';

@UseGuards(JwtAuthGuard) // Bảo vệ tất cả các endpoint bằng xác thực JWT
@Controller('organizations')
export class OrganizationsController {
    constructor(private readonly organizationsService: OrganizationsService) {}

    // Lấy danh sách tổ chức của người dùng đang đăng nhập
    @Get()
    getMyOrganizations(@Req() req: { user: User }) {
        return this.organizationsService.findOrganizationsByUserId(req.user.id);
    }
    
    /**
     * === CÁC ENDPOINT MỚI CHO QUẢN LÝ THÀNH VIÊN ===
     * Ở bước tiếp theo, chúng ta sẽ áp dụng OrganizationMemberGuard chi tiết hơn cho các endpoint này.
     */

    @Get(':orgId/members')
    // TODO: Áp dụng Guard yêu cầu là thành viên của orgId
    getMembers(@Param('orgId', ParseUUIDPipe) orgId: string) {
        return this.organizationsService.getMembers(orgId);
    }

    @Post(':orgId/members')
    @HttpCode(HttpStatus.CREATED)
    // TODO: Áp dụng Guard yêu cầu vai trò 'owner' hoặc 'admin'
    inviteMember(
        @Param('orgId', ParseUUIDPipe) orgId: string,
        @Body() inviteMemberDto: InviteMemberDto,
    ) {
        return this.organizationsService.inviteMember(orgId, inviteMemberDto.email, inviteMemberDto.role);
    }

    @Patch(':orgId/members/:userId')
    // TODO: Áp dụng Guard yêu cầu vai trò 'owner' hoặc 'admin'
    updateMemberRole(
        @Param('orgId', ParseUUIDPipe) orgId: string,
        @Param('userId', ParseIntPipe) userId: number,
        @Body() updateMemberRoleDto: UpdateMemberRoleDto,
    ) {
        return this.organizationsService.updateMemberRole(orgId, userId, updateMemberRoleDto.role);
    }

    @Delete(':orgId/members/:userId')
    @HttpCode(HttpStatus.NO_CONTENT)
    // TODO: Áp dụng Guard yêu cầu vai trò 'owner' hoặc 'admin'
    removeMember(
        @Param('orgId', ParseUUIDPipe) orgId: string,
        @Param('userId', ParseIntPipe) userId: number,
    ) {
        return this.organizationsService.removeMember(orgId, userId);
    }
}