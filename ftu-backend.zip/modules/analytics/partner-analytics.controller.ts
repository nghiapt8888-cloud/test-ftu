// File: ftu-backend/modules/analytics/partner-analytics.controller.ts
import { Controller, Get, UseGuards, Req } from '@nestjs/common';
import { JwtAuthGuard } from '../../core/auth/guards/jwt-auth.guard';
import { PartnerGuard } from '../../core/auth/guards/partner.guard';
import { User } from '../accounts/entities/user.entity';
import { PartnersService } from '../partners/partners.service';
import { PartnerAnalyticsService } from './partner-analytics.service';

@Controller('partner/analytics')
@UseGuards(JwtAuthGuard, PartnerGuard) // Chỉ Partner mới được truy cập
export class PartnerAnalyticsController {
    constructor(
        private readonly partnerAnalyticsService: PartnerAnalyticsService,
        private readonly partnersService: PartnersService,
    ) {}

    @Get('summary')
    async getSummary(@Req() req: { user: User }) {
        // Lấy thông tin partner từ user đang đăng nhập
        const partner = await this.partnersService.getMyProfile(req.user);
        return this.partnerAnalyticsService.getDashboardSummary(partner.id);
    }
}