// File: ftu-backend/src/modules/analytics/analytics.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AnalyticsService } from './analytics.service';
import { AnalyticsController } from './analytics.controller';
import { AuthModule } from '../../core/auth/auth.module';
import { User } from '../accounts/entities/user.entity';
import { Subscription } from '../billing/entities/subscription.entity';
import { Organization } from '../organizations/entities/organization.entity';
import { Transaction } from '../wallets/entities/transaction.entity';
import { PartnerAnalyticsService } from './partner-analytics.service'; // <-- IMPORT MỚI
import { PartnerAnalyticsController } from './partner-analytics.controller'; // <-- IMPORT MỚI
import { Partner } from '../partners/entities/partner.entity'; // <-- IMPORT MỚI
import { PartnersModule } from '../partners/partners.module'; // <-- IMPORT MỚI

@Module({
  imports: [
    TypeOrmModule.forFeature([
      User,
      Subscription,
      Organization,
      Transaction,
      Partner,
    ]),
    AuthModule,
    PartnersModule,
  ],
  controllers: [
    AnalyticsController,
    PartnerAnalyticsController,
  ],
  providers: [
    AnalyticsService,
    PartnerAnalyticsService,
  ],
})
export class AnalyticsModule {}