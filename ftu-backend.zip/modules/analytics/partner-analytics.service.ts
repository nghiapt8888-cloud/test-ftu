// File: ftu-backend/src/modules/analytics/partner-analytics.service.ts
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Subscription } from '../billing/entities/subscription.entity';
import { Partner } from '../partners/entities/partner.entity';

@Injectable()
export class PartnerAnalyticsService {
    constructor(
        @InjectRepository(Subscription)
        private readonly subscriptionRepository: Repository<Subscription>,
        @InjectRepository(Partner)
        private readonly partnerRepository: Repository<Partner>,
    ) {}

    /**
     * Lấy dữ liệu tổng quan cho dashboard của một đối tác cụ thể.
     * @param partnerId - ID của đối tác cần lấy dữ liệu.
     */
    async getDashboardSummary(partnerId: string) {
        const partner = await this.partnerRepository.findOneBy({ id: partnerId });
        if (!partner) {
            throw new NotFoundException(`Không tìm thấy đối tác với ID ${partnerId}.`);
        }

        // Tạo một query builder để lấy dữ liệu từ các subscription liên quan
        const queryBuilder = this.subscriptionRepository.createQueryBuilder('subscription')
            .innerJoin('subscription.plan', 'plan')
            .innerJoin('plan.solution', 'solution')
            .where('solution.partnerId = :partnerId', { partnerId });

        // Sử dụng Promise.all để chạy các truy vấn song song
        const [totalRevenue, totalSales, topSolutions] = await Promise.all([
            // Tính tổng doanh thu
            queryBuilder.select('SUM(plan.price)', 'total').getRawOne(),
            // Đếm tổng số lượt bán
            queryBuilder.getCount(),
            // Lấy 3 giải pháp bán chạy nhất
            queryBuilder
                .clone() // Clone để không ảnh hưởng đến các query khác
                .select('solution.name', 'name')
                .addSelect('COUNT(subscription.id)', 'sales')
                .groupBy('solution.name')
                .orderBy('sales', 'DESC')
                .limit(3)
                .getRawMany(),
        ]);

        return {
            totalRevenue: parseFloat(totalRevenue.total) || 0,
            totalSales,
            topSolutions,
        };
    }
}