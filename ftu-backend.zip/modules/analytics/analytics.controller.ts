// File: ftu-backend/src/modules/analytics/analytics.controller.ts
import { Controller, Get, UseGuards } from '@nestjs/common';
import { AnalyticsService } from './analytics.service';
import { JwtAuthGuard } from '../../core/auth/guards/jwt-auth.guard';
import { SystemAdminGuard } from '../../core/auth/guards/system-admin.guard';

@UseGuards(JwtAuthGuard, SystemAdminGuard) // Bảo vệ toàn bộ controller
@Controller('analytics')
export class AnalyticsController {
  constructor(private readonly analyticsService: AnalyticsService) {}

  /**
   * Cung cấp dữ liệu tóm tắt cho KPI Dashboard chính.
   */
  @Get('summary')
  getDashboardSummary() {
    return this.analyticsService.getDashboardSummary();
  }

  /**
   * Cung cấp danh sách các giao dịch gần đây để hiển thị trên dashboard.
   */
  @Get('recent-transactions')
  getRecentTransactions() {
    // Mặc định lấy 10 giao dịch gần nhất
    return this.analyticsService.getRecentTransactions();
  }
}