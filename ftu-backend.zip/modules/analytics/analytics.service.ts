// File: ftu-backend/src/modules/analytics/analytics.service.ts
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from '../accounts/entities/user.entity';
import { Subscription } from '../billing/entities/subscription.entity';
import { Organization } from '../organizations/entities/organization.entity';
import { Transaction } from '../wallets/entities/transaction.entity';

@Injectable()
export class AnalyticsService {
    constructor(
        @InjectRepository(User)
        private readonly userRepository: Repository<User>,
        @InjectRepository(Subscription)
        private readonly subscriptionRepository: Repository<Subscription>,
        @InjectRepository(Organization)
        private readonly organizationRepository: Repository<Organization>,
        @InjectRepository(Transaction)
        private readonly transactionRepository: Repository<Transaction>,
    ) {}

    /**
     * Lấy về các chỉ số tổng quan cho KPI Dashboard.
     */
    async getDashboardSummary() {
        // Sử dụng Promise.all để các câu truy vấn chạy song song, tăng hiệu năng
        const [
            totalUsers,
            totalOrganizations,
            totalSubscriptions,
            totalRevenue,
        ] = await Promise.all([
            this.userRepository.count(),
            this.organizationRepository.count(),
            this.subscriptionRepository.count({ where: { status: 'active' } }),
            this.calculateTotalRevenue(),
        ]);

        return {
            totalUsers,
            totalOrganizations,
            activeSubscriptions: totalSubscriptions,
            totalRevenue,
        };
    }

    /**
     * Tính tổng doanh thu từ các giao dịch mua/đăng ký.
     * Lưu ý: Hàm này giả định 'purchase' là loại giao dịch khi mua gói.
     * Cần điều chỉnh `TransactionType` nếu có thay đổi.
     */
    private async calculateTotalRevenue(): Promise<number> {
        const result = await this.transactionRepository
            .createQueryBuilder('transaction')
            .select('SUM(ABS(transaction.amount))', 'total') // Lấy giá trị tuyệt đối vì 'purchase' có thể là số âm
            .where('transaction.type = :type', { type: 'purchase' })
            .getRawOne();

        // getRawOne() trả về { total: "..." } dạng chuỗi, cần chuyển đổi sang số
        return parseFloat(result.total) || 0;
    }

    /**
     * Lấy danh sách các giao dịch gần đây.
     */
    async getRecentTransactions(limit = 10): Promise<Transaction[]> {
        return this.transactionRepository.find({
            order: { createdAt: 'DESC' },
            take: limit,
            relations: ['wallet', 'wallet.organization'], // Lấy thêm thông tin tổ chức
        });
    }
}