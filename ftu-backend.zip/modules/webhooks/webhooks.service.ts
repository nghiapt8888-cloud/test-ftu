// File: ftu-backend/src/modules/webhooks/webhooks.service.ts
import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { HttpService } from '@nestjs/axios';
import { AxiosError } from 'axios';
import { firstValueFrom } from 'rxjs';

import { Subscription } from '../billing/entities/subscription.entity';
import { WebhookLog, WebhookStatus } from '../../platform_admin/webhooks_monitor/entities/webhook-log.entity';

@Injectable()
export class WebhooksService {
    private readonly logger = new Logger(WebhooksService.name);

    constructor(
        @InjectRepository(WebhookLog)
        private readonly webhookLogRepository: Repository<WebhookLog>,
        private readonly httpService: HttpService,
    ) {}

    /**
     * Gửi một sự kiện liên quan đến subscription đến webhook endpoint của đối tác.
     * @param eventType - Loại sự kiện, ví dụ: 'subscription.created'
     * @param subscription - Đối tượng subscription liên quan đến sự kiện
     */
    async sendSubscriptionEvent(eventType: string, subscription: Subscription): Promise<void> {
        const webhookEndpoint = subscription.plan.solution.webhookEndpoint;

        if (!webhookEndpoint) {
            this.logger.warn(`Solution ${subscription.plan.solution.id} does not have a webhook endpoint configured. Skipping.`);
            return;
        }

        // Xây dựng payload để gửi đi
        const payload = {
            event: eventType,
            data: {
                subscriptionId: subscription.id,
                organizationId: subscription.organization.id,
                planId: subscription.plan.id,
                status: subscription.status,
                currentPeriodEnd: subscription.currentPeriodEnd,
                createdAt: subscription.createdAt,
            },
        };

        const log = this.webhookLogRepository.create({
            subscription,
            eventType,
            endpointUrl: webhookEndpoint,
            payload,
        });

        try {
            this.logger.log(`Sending webhook for event ${eventType} to ${webhookEndpoint}`);

            const response = await firstValueFrom(
                this.httpService.post(webhookEndpoint, payload, {
                    headers: { 'Content-Type': 'application/json' },
                    timeout: 5000, // Timeout sau 5 giây
                }),
            );

            // Ghi log thành công
            log.status = 'success';
            log.responseStatusCode = response.status;
            log.responseBody = typeof response.data === 'string' ? response.data : JSON.stringify(response.data);
            this.logger.log(`Webhook sent successfully to ${webhookEndpoint}. Status: ${response.status}`);

        } catch (error) {
            const err = error as AxiosError;
            
            // Ghi log thất bại
            log.status = 'failed';
            if (err.response) {
                log.responseStatusCode = err.response.status;
                log.responseBody = typeof err.response.data === 'string' ? err.response.data : JSON.stringify(err.response.data);
                this.logger.error(`Webhook failed for ${webhookEndpoint}. Status: ${err.response.status}. Response: ${log.responseBody}`);
            } else {
                // Lỗi mạng hoặc timeout
                log.responseBody = err.message;
                this.logger.error(`Webhook failed for ${webhookEndpoint}. Error: ${err.message}`);
            }
        } finally {
            // Lưu lại kết quả vào CSDL
            await this.webhookLogRepository.save(log);
        }
    }
}