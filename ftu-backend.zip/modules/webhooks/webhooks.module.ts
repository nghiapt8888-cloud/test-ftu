// File: ftu-backend/src/modules/webhooks/webhooks.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HttpModule } from '@nestjs/axios';
import { WebhooksService } from './webhooks.service';
import { WebhookLog } from '../../platform_admin/webhooks_monitor/entities/webhook-log.entity';

@Module({
  imports: [
    HttpModule, // Import HttpModule để có thể inject HttpService
    TypeOrmModule.forFeature([WebhookLog]), // Đăng ký entity WebhookLog
  ],
  providers: [WebhooksService],
  exports: [WebhooksService], // Xuất service để các module khác (như BillingService) có thể dùng
})
export class WebhooksModule {}