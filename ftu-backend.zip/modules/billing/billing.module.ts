// File: ftu-backend/src/modules/billing/billing.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BillingService } from './billing.service';
import { BillingController } from './billing.controller';
import { Subscription } from './entities/subscription.entity';
import { MarketplaceModule } from '../marketplace/marketplace.module';
import { WebhooksModule } from '../webhooks/webhooks.module';
import { AuthModule } from '../../core/auth/auth.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Subscription]),
    MarketplaceModule, // Cần truy cập Plans
    WebhooksModule,    // Cần để gửi thông báo sau khi đăng ký thành công
    AuthModule,        // Cần để bảo vệ endpoints
  ],
  controllers: [BillingController],
  providers: [BillingService],
})
export class BillingModule {}