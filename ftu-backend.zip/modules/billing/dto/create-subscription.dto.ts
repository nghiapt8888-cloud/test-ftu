// File: ftu-backend/src/modules/billing/dto/create-subscription.dto.ts
import { IsUUID, IsNotEmpty } from 'class-validator';

export class CreateSubscriptionDto {
    @IsNotEmpty({ message: 'ID của Gói cước không được để trống.' })
    @IsUUID('4', { message: 'ID của Gói cước phải là một UUID hợp lệ.' })
    planId: string;

    @IsNotEmpty({ message: 'ID của Tổ chức không được để trống.' })
    @IsUUID('4', { message: 'ID của Tổ chức phải là một UUID hợp lệ.' })
    organizationId: string;

    // Thông tin thanh toán sẽ được xử lý riêng, 
    // ví dụ: paymentMethodId từ Stripe hoặc chỉ định thanh toán bằng Wallet.
}