// File: ftu-backend/src/modules/billing/entities/subscription.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Organization } from '../../organizations/entities/organization.entity';
import { Plan } from '../../marketplace/entities/plan.entity';

@Entity('billing_subscriptions')
export class Subscription {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @ManyToOne(() => Organization)
    @JoinColumn({ name: 'organization_id' })
    organization: Organization;

    @ManyToOne(() => Plan)
    @JoinColumn({ name: 'plan_id' })
    plan: Plan;

    @Column({ 
        type: 'enum',
        enum: ['trialing', 'active', 'past_due', 'canceled'],
    })
    status: 'trialing' | 'active' | 'past_due' | 'canceled';

    @Column({ name: 'current_period_end', type: 'timestamp' })
    currentPeriodEnd: Date; // Ngày hết hạn của gói cước

    @CreateDateColumn({ name: 'created_at' })
    createdAt: Date;
}