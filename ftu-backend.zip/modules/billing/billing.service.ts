// File: ftu-backend/src/modules/billing/billing.service.ts
import { Injectable, NotFoundException, BadRequestException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { addMonths, addYears } from 'date-fns';

import { Subscription } from './entities/subscription.entity';
import { Plan } from '../marketplace/entities/plan.entity';
import { MarketplaceService } from '../marketplace/marketplace.service';
import { WebhooksService } from '../webhooks/webhooks.service';
import { CreateSubscriptionDto } from './dto/create-subscription.dto';
import { User } from '../accounts/entities/user.entity';
import { AffiliatesService } from '../affiliates/affiliates.service';
import { MembershipsService } from '../memberships/memberships.service';
import { OrganizationsService } from '../organizations/organizations.service';
import { WalletsService } from '../wallets/wallets.service';

@Injectable()
export class BillingService {
    private readonly logger = new Logger(BillingService.name);

    constructor(
        @InjectRepository(Subscription)
        private readonly subscriptionRepository: Repository<Subscription>,
        private readonly marketplaceService: MarketplaceService,
        private readonly webhooksService: WebhooksService,
        private readonly affiliatesService: AffiliatesService,
        private readonly membershipsService: MembershipsService,
        private readonly organizationsService: OrganizationsService,
        private readonly walletsService: WalletsService,
        private readonly dataSource: DataSource,
    ) {}

    async createSubscription(dto: CreateSubscriptionDto, user: User): Promise<Subscription> {
        const { planId, organizationId } = dto;

        // Ghi log khởi tạo
        this.logger.log(`User ${user.email} initiating subscription for plan ${planId} for org ${organizationId}`);

        return this.dataSource.transaction(async manager => {
            // 1. Lấy thông tin gói cước và tổ chức
            const plan = await manager.findOne(Plan, { where: { id: planId }, relations: ['solution'] });
            if (!plan) {
                throw new NotFoundException(`Gói cước với ID ${planId} không tồn tại.`);
            }

            const organization = await this.organizationsService.findOneById(organizationId);
            if (!organization) {
                throw new NotFoundException(`Tổ chức với ID ${organizationId} không tồn tại.`);
            }

            // 2. Lấy ví và kiểm tra số dư, tính toán giá cuối cùng
            const wallet = await this.walletsService.getWalletByOrgId(organizationId);
            const activeMembership = await this.membershipsService.getActiveMembershipForOrg(organizationId);
            
            let finalPrice = plan.price;
            let description = `Thanh toán cho gói '${plan.name}'`;

            if (activeMembership && activeMembership.plan?.benefits?.solutionDiscountRate > 0) {
                const discountRate = activeMembership.plan.benefits.solutionDiscountRate;
                finalPrice = plan.price * (1 - discountRate);
                description += ` (Đã áp dụng giảm giá thành viên ${discountRate * 100}%)`;
                // Ghi log khi áp dụng giảm giá
                this.logger.log(`Applied ${discountRate * 100}% membership discount. Original price: ${plan.price}, Final price: ${finalPrice}`);
            }

            if (wallet.balance < finalPrice) {
                // Ghi log cảnh báo khi số dư không đủ
                this.logger.warn(`Insufficient balance for org ${organizationId}. Required: ${finalPrice}, Available: ${wallet.balance}`);
                throw new BadRequestException('Số dư trong ví không đủ để thực hiện thanh toán.');
            }

            // 3. Trừ tiền từ ví (quan trọng)
            await this.walletsService.recordTransaction(
                wallet,
                'purchase',
                -finalPrice, // Số tiền trừ đi là số âm
                description,
                user,
                manager // Truyền transaction manager vào để đảm bảo tính toàn vẹn
            );

            // 4. Tính toán ngày hết hạn
            const now = new Date();
            const periodEnd = plan.billingCycle === 'monthly'
                ? addMonths(now, 1)
                : addYears(now, 1);

            // 5. Tạo bản ghi Subscription mới
            const newSubscription = manager.create(Subscription, {
                organization,
                plan,
                status: 'active',
                currentPeriodEnd: periodEnd,
            });
            const savedSubscription = await manager.save(newSubscription);

            // 6. KIỂM TRA LOGIC MEMBERSHIP
            if (plan.solution.isInternal) {
                await this.membershipsService.createOrUpdateUserMembership(organization, savedSubscription);
            } else {
                // 7. Kích hoạt Webhook (chỉ cho sản phẩm của partner)
                await this.webhooksService.sendSubscriptionEvent('subscription.created', savedSubscription);
            }
            
            // 8. Ghi nhận hoa hồng cho người giới thiệu (nếu có)
            await this.affiliatesService.recordCommission(savedSubscription, user);

            // Ghi log thành công
            this.logger.log(`Successfully created subscription ${savedSubscription.id} for org ${organizationId}`);
            
            return savedSubscription;
        });
    }

    async findSubscriptionsByOrganization(organizationId: string): Promise<Subscription[]> {
        return this.subscriptionRepository.find({
            where: { organization: { id: organizationId } },
            relations: ['plan', 'plan.solution'],
            order: { createdAt: 'DESC' },
        });
    }
}