// File: ftu-backend/src/modules/billing/billing.controller.ts
import { Controller, Post, Body, Get, UseGuards, Req, Query, ParseUUIDPipe } from '@nestjs/common';
import { BillingService } from './billing.service';
import { CreateSubscriptionDto } from './dto/create-subscription.dto';
import { JwtAuthGuard } from '../../core/auth/guards/jwt-auth.guard';
import { User } from '../accounts/entities/user.entity';
import { OrganizationMemberGuard } from '../../core/auth/guards/organization-member.guard'; // <-- IMPORT MỚI
import { Roles } from '../../core/auth/decorators/roles.decorator'; // <-- IMPORT MỚI

@UseGuards(JwtAuthGuard) // Yêu cầu đăng nhập cho tất cả endpoint
@Controller('billing')
export class BillingController {
    constructor(private readonly billingService: BillingService) {}

    @Post('subscribe')
    @Roles('owner', 'admin') // <-- YÊU CẦU VAI TRÒ OWNER HOẶC ADMIN
    @UseGuards(OrganizationMemberGuard) // <-- ÁP DỤNG GUARD KIỂM TRA VAI TRÒ
    createSubscription(@Body() dto: CreateSubscriptionDto, @Req() req: { user: User }) {
        // Guard sẽ đảm bảo user có quyền 'owner' hoặc 'admin' trên organizationId trong DTO
        return this.billingService.createSubscription(dto, req.user);
    }

    @Get('subscriptions')
    @Roles('owner', 'admin', 'member') // <-- CHO PHÉP TẤT CẢ THÀNH VIÊN
    @UseGuards(OrganizationMemberGuard) // <-- ÁP DỤNG GUARD KIỂM TRA VAI TRÒ
    findSubscriptions(@Query('organizationId', ParseUUIDPipe) organizationId: string, @Req() req: { user: User }) {
        // Guard sẽ đảm bảo user là thành viên của organizationId
        return this.billingService.findSubscriptionsByOrganization(organizationId);
    }
}