// File: ftu-backend/src/shared/services/encryption.service.ts
import { Injectable, InternalServerErrorException, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as crypto from 'crypto';

@Injectable()
export class EncryptionService {
    private readonly logger = new Logger(EncryptionService.name);
    private readonly algorithm = 'aes-256-gcm';
    private readonly key: Buffer;
    private readonly ivLength = 16; // For GCM, IV is typically 12 or 16 bytes. We'll use 16.
    private readonly authTagLength = 16;

    constructor(private readonly configService: ConfigService) {
        const encryptionKey = this.configService.get<string>('ENCRYPTION_KEY');
        if (!encryptionKey || Buffer.from(encryptionKey, 'hex').length !== 32) {
            this.logger.error('ENCRYPTION_KEY is missing or not a 32-byte hex string in .env file.');
            throw new InternalServerErrorException('Encryption service is not configured correctly.');
        }
        this.key = Buffer.from(encryptionKey, 'hex');
    }

    /**
     * Mã hóa một chuỗi văn bản.
     * @param text - Chuỗi cần mã hóa.
     * @returns Một chuỗi đã được mã hóa, bao gồm iv, authTag và nội dung.
     */
    encrypt(text: string): string {
        try {
            const iv = crypto.randomBytes(this.ivLength);
            const cipher = crypto.createCipheriv(this.algorithm, this.key, iv);
            
            const encryptedBuffer = Buffer.concat([cipher.update(text, 'utf8'), cipher.final()]);
            const authTag = cipher.getAuthTag();

            // Ghép iv, authTag và nội dung đã mã hóa thành một chuỗi duy nhất để lưu trữ
            return Buffer.concat([iv, authTag, encryptedBuffer]).toString('hex');
        } catch (error) {
            this.logger.error(`Encryption failed: ${error.message}`, error.stack);
            throw new InternalServerErrorException('Could not encrypt data.');
        }
    }

    /**
     * Giải mã một chuỗi đã được mã hóa bởi hàm encrypt.
     * @param encryptedText - Chuỗi hex đã được mã hóa.
     * @returns Chuỗi văn bản gốc.
     */
    decrypt(encryptedText: string): string {
        try {
            const encryptedBuffer = Buffer.from(encryptedText, 'hex');
            
            const iv = encryptedBuffer.slice(0, this.ivLength);
            const authTag = encryptedBuffer.slice(this.ivLength, this.ivLength + this.authTagLength);
            const encryptedContent = encryptedBuffer.slice(this.ivLength + this.authTagLength);

            const decipher = crypto.createDecipheriv(this.algorithm, this.key, iv);
            decipher.setAuthTag(authTag);

            const decryptedBuffer = Buffer.concat([decipher.update(encryptedContent), decipher.final()]);

            return decryptedBuffer.toString('utf8');
        } catch (error) {
            this.logger.error(`Decryption failed. The key may be wrong or data corrupted: ${error.message}`);
            throw new InternalServerErrorException('Could not decrypt data.');
        }
    }
}